#include "TrainScheduleModel.h"

#include "TrainTreeModel.h"


#include <QFile>
#include <QJsonObject>
#include <QJsonDocument>
#include <QJsonParseError>
#include <QDebug>

using namespace schedulemodel;

TrainScheduleModel::TrainScheduleModel(QWidget *parent)
	: QMainWindow(parent)
{
	ui.setupUi(this);
}


void TrainScheduleModel::load()
{
	QString schedulePath = QString("schedule.json");
	QFile scheduleFile(schedulePath);

	if (!scheduleFile.open(QIODevice::ReadOnly | QIODevice::Text))
	{
		qDebug() << "Can't open file" << scheduleFile.errorString();
		return;
	}
	else
	{
		QJsonParseError err;
		QJsonDocument doc = QJsonDocument::fromJson(scheduleFile.readAll(), &err);
		if (err.error != QJsonParseError::NoError)
		{
			qDebug() << "Wrong file, error: " << err.errorString();
			return;
		}
		else
		{
			model = new schedulemodel::TrainTreeModel();
			model->load(doc.object());
			ui.treeView->setModel(model);
			ui.treeView->update();
		}
	}
}
