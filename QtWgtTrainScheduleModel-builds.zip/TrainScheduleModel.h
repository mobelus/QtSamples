#pragma once

#include <QtWidgets/QMainWindow>
#include "ui_TrainScheduleModel.h"

namespace schedulemodel
{
	class TrainTreeModel;
}

class TrainScheduleModel : public QMainWindow
{
	Q_OBJECT

public:
	TrainScheduleModel(QWidget *parent = Q_NULLPTR);
	void load();


private:
	Ui::TrainScheduleModelClass ui;
	schedulemodel::TrainTreeModel* model;
};
