#pragma once


#include <QString>
#include <QDateTime>
#include <QJsonObject>
#include <QJsonArray>
#include <QVector>

#include <QDebug>


namespace schedulemodel
{

	const char* const StationID			 = "stationId";
	const char* const StationName		 = "station";
	const char* const StationDescription = "stationDescription";
	const char* const StationArrivial	 = "timeArrival";
	const char* const StationDepature	 = "timeDeparture";
	//
	const char* const TrainNumber		 = "trainNumber";
	const char* const TrainDescription	 = "trainDescription";
	const char* const TrainStops		 = "stops";
	//
	const char* const RouteNumber		 = "routeNumber";
	const char* const RouteDescription	 = "routeDescription";
	const char* const TrainsInRoute		 = "trains";
	//
	const char* const DateTimeFormatTo	 = "hh:mm:ss dd.MM.yyyy";
	const char* const DateTimeFormatFrom = "yyyy-MM-ddThh:mm:ss";
	const char* const IntermediateFormat = "yyyy-MM-ddThh:mm:ss.zzz";


	class ScheduleModelItem
	{
	public:
		enum class ElemType
		{
			Root,
			Route,
			Train,
			Station
		};

		ScheduleModelItem(ScheduleModelItem* parent = nullptr)
		{
			_rootItem = parent;
			_type = ScheduleModelItem::ElemType::Root;
		}

		~ScheduleModelItem()
		{
			qDeleteAll(_data);
			_data.clear();
		}

		virtual bool load(const QJsonObject& trainItem, QString* error = nullptr)
		{
			return true;
		}
		//virtual QJsonObject save(QString* error = nullptr) const = 0;

		int childCount() const { return _data.size(); }

		ScheduleModelItem* getChild(int i) const
		{
			//return _data.value(i);
			ScheduleModelItem* child = nullptr;
			if (i >= 0 && i < _data.size())
				child = _data[i];
			return child;
		}

		void addChild(ScheduleModelItem* const child)
		{
			_data.push_back(child);
		}

		int getChildPosition(ScheduleModelItem * const child) const
		{
			return _data.indexOf(child);
		}


		ScheduleModelItem* getParent() const
		{
			return _rootItem;
		}


		ElemType type() const { return _type; }
		int id() const		  { return _id; };
		QString description() const { return _description; }


	protected:
		ElemType					_type;
		ScheduleModelItem*			_rootItem;
		QList<ScheduleModelItem*>	_data;
		//
		int			_id;
		QString		_description;
	};




	class StationItem : public ScheduleModelItem
	{
	public:
		StationItem(ScheduleModelItem* parent = nullptr) 
			: ScheduleModelItem(parent)
		{
			_type = ScheduleModelItem::ElemType::Station;
		}

		bool load(const QJsonObject& stationItem, QString* error = nullptr) override
		{
			bool res = false;
			if (!stationItem.isEmpty())
			{			
				QJsonValue jStationId    = stationItem[StationID];
				QJsonValue jStationName  = stationItem[StationName];
				QJsonValue jArrival		 = stationItem[StationArrivial];
				QJsonValue jDeparture	 = stationItem[StationDepature];

				_id			 = jStationId.toString().toInt();
				_name		 = jStationName.toString();
				_arrival	 = QDateTime::fromString(jArrival.toString().trimmed(), DateTimeFormatFrom);
				_depature	 = QDateTime::fromString(jDeparture.toString().trimmed(), DateTimeFormatFrom);
				_description = QObject::tr("station");

				res = true;
			}
			else
			{
				if (error)
					*error = "Empty json to initialize station item";
			}

			return res;
		}


		QJsonObject save() const
		{
			QJsonObject result;

			result[StationID] = _id;
			result[StationName] = _name;
			result[StationArrivial] = _arrival.toString(DateTimeFormatFrom);
			result[StationDepature] = _arrival.toString(DateTimeFormatFrom);
			//
			return result;
		}
		
		//
		QString		_name;
		QDateTime	_arrival;
		QDateTime	_depature;
	};


	//bool operator == (const StationItem& lhs, const StationItem& rhs)
	//{
	//	return ((lhs._id == rhs._id) && (lhs._name == rhs._name) &&
	//		(lhs._arrival == rhs._arrival) &&
	//		(lhs._depature == rhs._depature));
	//}



	//template <typename ChildElement>
	//class RootScheduleElement : public ScheduleModelItem
	//{	
	//public:
	//	virtual bool load(const QJsonObject& trainItem, QString* error = nullptr) = 0;
	//	virtual bool loadChilds(const QJsonArray& childItems, QString* error = nullptr)
	//	{
	//		for (int i = 0; i < childItems.size(); ++i)
	//		{
	//			ChildElement newItem;
	//			if (newItem.load(childItems[i].toObject(), &err))
	//			{
	//				_childs.push_back(newItem);
	//			}
	//			else
	//			{
	//				if (error)
	//					*error = err;
	//				break;
	//			}
	//		}
	//	}
	//};


	

	class TrainItem : public ScheduleModelItem
	{
	public:
		TrainItem(ScheduleModelItem* parent = nullptr) : ScheduleModelItem(parent)
		{
			_type = ScheduleModelItem::ElemType::Train;
		}

		bool load(const QJsonObject& trainItem, QString* error = nullptr) override
		{
			bool res = false;
			QString err;

			if (!trainItem.isEmpty())
			{				
				_id = trainItem[TrainNumber].toString().toInt();
				_description = QObject::tr("train");//trainItem[TrainDescription].toString();

				QJsonArray stationItems = trainItem[TrainStops].toArray();

				for (int i = 0; i < stationItems.size(); ++i)
				{
					ScheduleModelItem* newItem = new StationItem(this);
					res = newItem->load(stationItems[i].toObject(), &err);
					if (res)
					{
						_data.push_back(newItem);
					}
					else
					{
						delete newItem;
						if (error)
							*error = err;
						break;
					}
				}
			}
			else
			{
				if (error)
					*error = "Empty json to initialize train item";
			}
			//
			return res;
		}
	};



	class RouteItem : public ScheduleModelItem
	{
	public:
		RouteItem(ScheduleModelItem* parent = nullptr) : ScheduleModelItem(parent)
		{
			_type = ScheduleModelItem::ElemType::Route;			
		}

		bool load(const QJsonObject& routeItem, QString* error = nullptr) override
		{
			bool res = false;
			QString err;

			if (!routeItem.isEmpty())
			{
				_id			 = routeItem[RouteNumber].toString().toInt();
				_description = QObject::tr("route"); //routeItem[RouteDescription].toString();

				QJsonArray trainItems = routeItem[TrainsInRoute].toArray();

				for (int i = 0; i < trainItems.size(); ++i)
				{
					ScheduleModelItem* newItem = new TrainItem(this);
					res = newItem->load(trainItems[i].toObject(), &err);
					if (res)
					{
						_data.push_back(newItem);
					}
					else
					{
						delete newItem;
						if (error)
							*error = err;
						break;
					}
				}
			}
			else
			{
				if (error)
					*error = "Empty json to initialize route item";
			}
			//
			return res;
		}
	};





} // schedulemodel