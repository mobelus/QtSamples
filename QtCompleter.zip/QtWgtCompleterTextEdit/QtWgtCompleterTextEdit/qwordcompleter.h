#ifndef QWORDCOMPLETER_H
#define QWORDCOMPLETER_H

#include <QCompleter>

class QWordCompleter : public QCompleter
{
public:
	QWordCompleter(const QStringList& completions, QObject *parent = Q_NULLPTR);
	~QWordCompleter();

	//
public:
	virtual bool eventFilter(QObject *o, QEvent *e);

	int getMinCompletionLenght() const;
	void setMinCompletionLenght(int value);

private:
	int minCompletionLenght = 1;
};

#endif // QWORDCOMPLETER_H
