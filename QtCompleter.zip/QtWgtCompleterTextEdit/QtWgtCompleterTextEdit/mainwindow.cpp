#include "mainwindow.h"
#include "ui_mainwindow.h"

#include "qwordcompleter.h"

MainWindow::MainWindow(QWidget *parent) :
	QMainWindow(parent),
	ui(new Ui::MainWindow)
{
	ui->setupUi(this);

	QStringList keywords;
	keywords << "SELECT" << "FROM" << "WHERE" << "ORDER" << "BY" << "DELETE" << "DROP" << "SELENA" << "SERBIA";

	//QCompleter* compl = new QCompleter(keywords, this);
	QWordCompleter* completer = new QWordCompleter(keywords, this);
	completer->setCaseSensitivity(Qt::CaseInsensitive);

	//ui->comboBox->setCompleter(compl);
	//ui->lineEdit->setCompleter(compl);

	completer->setWidget(ui->textEdit);
}

MainWindow::~MainWindow()
{
	delete ui;
}
