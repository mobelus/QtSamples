#include "qwordcompleter.h"

#include <QEvent>
#include <QKeyEvent>
#include <QAbstractItemView>
#include <QTextEdit>
#include <QTextCursor>

QWordCompleter::QWordCompleter(const QStringList& completions, QObject *parent) :
	QCompleter(completions, parent)
{

}

QWordCompleter::~QWordCompleter()
{

}

bool QWordCompleter::eventFilter(QObject *o, QEvent *e)
{
	// ALMOST WORKING VERSION
	if(widget()->inherits("QTextEdit") && e->type() == QEvent::KeyPress)
	{
		QKeyEvent* kEv = static_cast<QKeyEvent*> (e);
		switch(kEv->key())
		{
		//	case Qt::Key_Space:
		//	break;
		case Qt::Key_Enter:
		case Qt::Key_Return:
		case Qt::Key_Tab:
			if(popup()->isVisible())
			{
				popup()->hide();
				if(popup()->currentIndex().isValid())
				{
					emit activated(popup()->currentIndex());
					emit activated(popup()->currentIndex().data(completionRole()).toString());
				}
				return true;
			}
		default:
			//if(kEv->modifiers().testFlag(Qt::ControlModifier))
			{
				// от начала слова, до курсора
				QTextEdit* textEdit = qobject_cast<QTextEdit*>(widget());
				QTextCursor textCursor = textEdit->textCursor();
				textCursor.movePosition(QTextCursor::StartOfWord, QTextCursor::KeepAnchor);
				if(textCursor.selectedText().length() >= minCompletionLenght)
				{
					setCompletionPrefix(textCursor.selectedText()); // На 5 пикселей ниже курсора
					QRect rect  = QRect(textEdit->cursorRect().bottomLeft(), QSize(100, 5));
					complete(rect);
				}
				//return true;
				return QCompleter::eventFilter(o, e);
			}
		}
	}
//*/


/* // CTRL + SPACE - VERSION
	if(widget()->inherits("QTextEdit") && e->type() == QEvent::KeyPress)
	{
		QKeyEvent* kEv = static_cast<QKeyEvent*> (e);
		switch(kEv->key())
		{
			case Qt::Key_Space:
				if(kEv->modifiers().testFlag(Qt::ControlModifier))
				{
					// от начала слова, до курсора
					QTextEdit* textEdit = qobject_cast<QTextEdit*>(widget());
					QTextCursor textCursor = textEdit->textCursor();
					textCursor.movePosition(QTextCursor::StartOfWord, QTextCursor::KeepAnchor);
					if(textCursor.selectedText().length() >= minCompletionLenght)
					{
						setCompletionPrefix(textCursor.selectedText()); // На 5 пикселей ниже курсора
						QRect rect  = QRect(textEdit->cursorRect().bottomLeft(), QSize(100, 5));
						complete(rect);
					}
					return true;
				}
			break;
		case Qt::Key_Enter:
		case Qt::Key_Return:
		case Qt::Key_Tab:
			if(popup()->isVisible())
			{
				popup()->hide();
				if(popup()->currentIndex().isValid())
				{
					emit activated(popup()->currentIndex());
					emit activated(popup()->currentIndex().data(completionRole()).toString());
				}
				return true;
			}
		default:
		break;
		}
	}
//*/
	return QCompleter::eventFilter(o, e);
}

int QWordCompleter::getMinCompletionLenght() const
{
	return minCompletionLenght;
}

void QWordCompleter::setMinCompletionLenght(int value)
{
	minCompletionLenght = value;
}

