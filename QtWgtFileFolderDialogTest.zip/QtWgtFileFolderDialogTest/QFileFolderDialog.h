#ifndef QFILEFOLDERDIALOG_H
#define QFILEFOLDERDIALOG_H

#include <QMessageBox>
#include <QDialog>
#include <QtCore>
#include <QtGui>
#include <QFileSystemModel>

namespace Ui {
class QFileFolderDialog;
}

class QFileFolderDialog : public QDialog
{
    Q_OBJECT

public:
    explicit QFileFolderDialog(QWidget *parent = 0);
    ~QFileFolderDialog();

    QString getChosenFilePath() const;
    void setChosenFilePath(const QString &value);

private slots:
    void on_btnCancel_clicked();
    void on_btnSelect_clicked();
    void on_editFullPath_editingFinished();
    void on_cmbxFileExtension_currentIndexChanged(const QString &arg1);
    void on_treeViewFolders_clicked(const QModelIndex &index);

signals:
    void clickedYes(QString chosen);

private:
    Ui::QFileFolderDialog *ui;

    QString chosenFilePath;

    QFileSystemModel* dirmodel;
    void setQDirFilterFromInt(int iFilter);
    QMap<QString, int> filtersNames;
};

#endif // QFILEFOLDERDIALOG_H
