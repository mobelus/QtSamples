#include "QFileFolderDialog.h"
#include "ui_QFileFolderDialog.h"

QFileFolderDialog::QFileFolderDialog(QWidget *parent) :
    QDialog(parent)
    , ui(new Ui::QFileFolderDialog)
    , dirmodel(new QFileSystemModel(this))
{
    ui->setupUi(this);
    setWindowTitle("Choose file or folder");

    QObject::connect(ui->btnCancel, SIGNAL(clicked()), this, SLOT(reject()));

    ui->listViewFiles->setVisible(false); // MUST SET TO FALSE
    //ui->treeViewFolders->setModel(dirmodel);
    //ui->treeViewFolders->setColumnWidth(0, 230);

    //filtersNames["*.* Files only"]   = static_cast<int>(QDir::NoDotAndDotDot | QDir::Files);
    filtersNames["Directories only"] = static_cast<int>(QDir::NoDotAndDotDot | QDir::AllDirs);
    filtersNames["Files and folders"]= static_cast<int>(QDir::Filter::NoFilter);
    //<< "*.exe"
    //<< "*.xml"
    //<< "*.docx, *.doc"

    // Unit Tests
    // //QString curFilterName = "Files and folders";
    // QString curFilterName = "Directories only";
    // int iFilter = filtersNames[curFilterName];
    // setQDirFilterFromInt(iFilter);
    // ui->cmbxFileExtension->addItem(curFilterName);

    ui->cmbxFileExtension->addItems(filtersNames.keys());
    int index = ui->cmbxFileExtension->findText("Files and folders");
    if ( index != -1 )
        ui->cmbxFileExtension->setCurrentIndex(index);

    QString s = getChosenFilePath();
    s = s;
}

QFileFolderDialog::~QFileFolderDialog()
{
    delete ui;
}

void QFileFolderDialog::on_btnCancel_clicked()
{
    close();
}

void QFileFolderDialog::on_btnSelect_clicked()
{
    QMessageBox::StandardButton reply;
    reply = QMessageBox::question(  this
                                  , "Attention!"
                                  , "Remove chosen data beyond recovery?"
                                  , QMessageBox::Yes|QMessageBox::No);
    if (reply == QMessageBox::Yes)
    {   //perform Shredding, De/Crypting
        //emit clickedYes( ui->editFullPath->text() );
        setChosenFilePath( ui->editFullPath->text() );
        //emit accepted();
        QDialog::accept();
    }
}

void QFileFolderDialog::on_editFullPath_editingFinished()
{
    //
}

void QFileFolderDialog::on_cmbxFileExtension_currentIndexChanged(const QString &curFilterName)
{
    // Unit Tests
    //QString curFilterName = "Files and folders";
    //QString curFilterName = "Directories only";
    int iFilter = filtersNames[curFilterName];
    //dirmodel->setFilter( getQDirFilterFromInt(iFilter) );
    setQDirFilterFromInt(iFilter);
    //ui->cmbxFileExtension->addItem(curFilterName);

}

void QFileFolderDialog::on_treeViewFolders_clicked(const QModelIndex &index)
{
    //QString filePath = dirmodel->filePath(index); //QString fileName = dirmodel->fileName(index);
    ui->editFullPath->setText(dirmodel->filePath(index));
}

QString QFileFolderDialog::getChosenFilePath() const
{
    return chosenFilePath;
}

void QFileFolderDialog::setChosenFilePath(const QString &value)
{
    QString defalutPath = "C:/"; // TO DO //
    if(value.isEmpty())
    {
        chosenFilePath = defalutPath;
    }
    else // restore
    {
        chosenFilePath = value;
    }

    dirmodel->setRootPath(chosenFilePath);
    ui->treeViewFolders->setModel(dirmodel);
    ui->treeViewFolders->setColumnWidth(0, 230);

    if(chosenFilePath != defalutPath)
    {
        QModelIndex mindex = dirmodel->index(chosenFilePath);
        ui->treeViewFolders->expand(mindex);
        ui->treeViewFolders->scrollTo(mindex);
        ui->treeViewFolders->setCurrentIndex(mindex);
        //ui->treeViewFolders->resizeColumnToContents(0); // Optional
    }
}



void QFileFolderDialog::setQDirFilterFromInt(int iFilter)
{
    switch(iFilter)
    {
    case static_cast<int>(QDir::Filter::NoFilter):
        dirmodel->setFilter( QDir::Filter::NoFilter );
        break;
    case static_cast<int>(QDir::Filter::NoDotAndDotDot | QDir::Filter::AllDirs):
        dirmodel->setFilter( QDir::Filter::NoDotAndDotDot | QDir::Filter::AllDirs );
        break;
    case static_cast<int>(QDir::NoDotAndDotDot | QDir::Files):
        dirmodel->setFilter( QDir::NoDotAndDotDot | QDir::Files );
        break;
    default:
        dirmodel->setFilter( QDir::Filter::NoFilter );
        break;
    }


    /*
        , static_cast<int>(QDir::Filter::Dirs           )
        , static_cast<int>(QDir::Filter::Files          )
        , static_cast<int>(QDir::Filter::Drives         )
        , static_cast<int>(QDir::Filter::NoSymLinks     )
        , static_cast<int>(QDir::Filter::AllEntries     )
        , static_cast<int>(QDir::Filter::TypeMask       )
        //static_cast<int>(,                            )
        , static_cast<int>(QDir::Filter::Readable       )
        , static_cast<int>(QDir::Filter::Writable       )
        , static_cast<int>(QDir::Filter::Executable     )
        , static_cast<int>(QDir::Filter::PermissionMask )
        //static_cast<int>(,                            )
        , static_cast<int>(QDir::Filter::Modified       )
        , static_cast<int>(QDir::Filter::Hidden         )
        , static_cast<int>(QDir::Filter::System         )
        , static_cast<int>(QDir::Filter::AccessMask     )
        , static_cast<int>(QDir::Filter::AllDirs        )
        , static_cast<int>(QDir::Filter::CaseSensitive  )
        , static_cast<int>(QDir::Filter::NoDot          )
        , static_cast<int>(QDir::Filter::NoDotDot       )
        , static_cast<int>(QDir::Filter::NoDotAndDotDot )
    */
}


/*
Filemodel->setFilter( QDir::NoDotAndDotDot | QDir::Files )  ;

QStringList filters;
filters << "*.txt";

Filemodel.setNameFilters(filters);
Filemodel.setNameFilterDisables(false);

ui->Filtered_tbView->setModel( Filemodel )                  ;
*/

/*
   QStringList sDriveFilters;
   QString sPath = m_SystemModel->fileInfo(index).absoluteFilePath();
   m_SystemListViewModel->setRootPath(sPath);
   ui->DriveListView->setRootIndex(m_SystemListViewModel->index(sPath));

   m_SystemModel->setRootPath(QDir::currentPath());
   m_SystemModel->setFilter(QDir::NoDotAndDotDot | QDir::AllDirs );
   m_SystemListViewModel->setFilter( QDir::Files | QDir::NoDotAndDotDot );
*/
