#include "QFileFolderDialog.h"
#include "ui_QFileFolderDialog.h"

QFileFolderDialog::QFileFolderDialog(QWidget *parent) :
    QDialog(parent)
    , ui(new Ui::QFileFolderDialog)
    , dirmodel(new QFileSystemModel(this))
{
    ui->setupUi(this);
    setWindowTitle("Choose file or folder");

    QObject::connect(ui->btnCancel, SIGNAL(clicked()), this, SLOT(reject()));

    ui->listViewFiles->setVisible(false); // MUST BE SET TO FALSE

    //filtersNames["*.* Files only"]   = static_cast<int>(QDir::NoDotAndDotDot | QDir::Files);
    filtersNames["Directories only"] = static_cast<int>(QDir::NoDotAndDotDot | QDir::AllDirs);
    filtersNames["Files and folders"]= static_cast<int>(QDir::Filter::NoFilter);
    // TO DO // Add some default filters ... maybe
    //<< "*.exe"
    //<< "*.docx, *.doc"

    ui->cmbxFileExtension->addItems(filtersNames.keys());
    int index = ui->cmbxFileExtension->findText("Files and folders");
    if ( index != -1 )
        ui->cmbxFileExtension->setCurrentIndex(index);
}

QFileFolderDialog::~QFileFolderDialog()
{
    delete ui;
}

void QFileFolderDialog::on_btnCancel_clicked()
{
    close();
}

void QFileFolderDialog::on_btnSelect_clicked()
{
    QFileInfo objectInfo( ui->editFullPath->text() );
    if (!objectInfo.exists())
    {
        QMessageBox::critical(  this
            , "Not found!"
            , "Chosen object does not exist!"
            );
        ui->editFullPath->setFocus();

        return;
    }


    QMessageBox::StandardButton reply;
    reply = QMessageBox::question(  this
                                  , "Attention!"
                                  , "Remove chosen data beyond recovery?"
                                  , QMessageBox::Yes|QMessageBox::No);
    if (reply == QMessageBox::Yes)
    {
        setChosenFilePath( ui->editFullPath->text() );

        //go to Shredding, De/Crypting
        QDialog::accept();
    }
}

void QFileFolderDialog::on_cmbxFileExtension_currentIndexChanged(const QString &curFilterName)
{
    // Unit Tests
    //QString curFilterName = "Files and folders";
    //QString curFilterName = "Directories only";
    int iFilter = filtersNames[curFilterName];
    setQDirFilterFromInt(iFilter);
}

void QFileFolderDialog::on_treeViewFolders_clicked(const QModelIndex &index)
{
    ui->editFullPath->setText( dirmodel->filePath(index) );
}

QString QFileFolderDialog::getChosenFilePath() const
{
    return chosenFilePath;
}

void QFileFolderDialog::setChosenFilePath(const QString &value)
{
    QString defalutPath = "C:/"; // TO DO //
    if(value.isEmpty())
    {
        chosenFilePath = defalutPath;
    }
    else // restore
    {
        chosenFilePath = value;
    }

    dirmodel->setRootPath(chosenFilePath);
    ui->treeViewFolders->setModel(dirmodel);
    ui->treeViewFolders->setColumnWidth(0, 230);

    if(chosenFilePath != defalutPath)
    {
        QModelIndex mindex = dirmodel->index(chosenFilePath);
        ui->treeViewFolders->expand(mindex);
        ui->treeViewFolders->scrollTo(mindex);
        ui->treeViewFolders->setCurrentIndex(mindex);
        //ui->treeViewFolders->resizeColumnToContents(0); // Optional
    }
}



void QFileFolderDialog::setQDirFilterFromInt(int iFilter)
{
    switch(iFilter)
    {
    case static_cast<int>(QDir::Filter::NoFilter):
        dirmodel->setFilter( QDir::Filter::NoFilter );
        break;
    case static_cast<int>(QDir::Filter::NoDotAndDotDot | QDir::Filter::AllDirs):
        dirmodel->setFilter( QDir::Filter::NoDotAndDotDot | QDir::Filter::AllDirs );
        break;
    case static_cast<int>(QDir::NoDotAndDotDot | QDir::Files):
        dirmodel->setFilter( QDir::NoDotAndDotDot | QDir::Files );
        break;
    default:
        dirmodel->setFilter( QDir::Filter::NoFilter );
        break;
    }


    /* // TO DO // Add more options if needed
        , static_cast<int>(QDir::Filter::Dirs           )
        , static_cast<int>(QDir::Filter::Files          )
        , static_cast<int>(QDir::Filter::Drives         )
        , static_cast<int>(QDir::Filter::NoSymLinks     )
        , static_cast<int>(QDir::Filter::AllEntries     )
        , static_cast<int>(QDir::Filter::TypeMask       )
        //static_cast<int>(,                            )
        , static_cast<int>(QDir::Filter::Readable       )
        , static_cast<int>(QDir::Filter::Writable       )
        , static_cast<int>(QDir::Filter::Executable     )
        , static_cast<int>(QDir::Filter::PermissionMask )
        //static_cast<int>(,                            )
        , static_cast<int>(QDir::Filter::Modified       )
        , static_cast<int>(QDir::Filter::Hidden         )
        , static_cast<int>(QDir::Filter::System         )
        , static_cast<int>(QDir::Filter::AccessMask     )
        , static_cast<int>(QDir::Filter::AllDirs        )
        , static_cast<int>(QDir::Filter::CaseSensitive  )
        , static_cast<int>(QDir::Filter::NoDot          )
        , static_cast<int>(QDir::Filter::NoDotDot       )
        , static_cast<int>(QDir::Filter::NoDotAndDotDot )
    */
}

