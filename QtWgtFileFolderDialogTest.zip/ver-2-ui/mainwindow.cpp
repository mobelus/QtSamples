#include "mainwindow.h"
#include "ui_mainwindow.h"

#include "QFileFolderDialog.h"

#include <QFileDialog>
#include <QDebug>
#include <QDir>
#include <QString>
#include <QTreeView>


MainWindow::MainWindow(QWidget *parent) :
      QMainWindow(parent)
    //, dlgFileFolder(new QFileFolderDialog(this))
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_pushButton_clicked()
{
/*
    QFileDialog *fd = new QFileDialog;
    QTreeView *tree = fd->findChild <QTreeView*>();
    tree->setRootIsDecorated(true);
    tree->setItemsExpandable(true);
    fd->setFileMode(QFileDialog::Directory);
    fd->setOption(QFileDialog::ShowDirsOnly);
    fd->setViewMode(QFileDialog::Detail);
    int result = fd->exec();
    QString directory;
    if (result)
    {
        directory = fd->selectedFiles()[0];
        qDebug()<<directory;
    }
*/

    QFileDialog fd;
    //QTreeView *tree = fd.findChild <QTreeView*>();
    //tree->setRootIsDecorated(true);
    //tree->setItemsExpandable(true);

    //fd.setFileMode(QFileDialog::Directory);
    //fd.setOption(QFileDialog::ShowDirsOnly | QFileDialog::DontUseNativeDialog | );
    fd.setFileMode(QFileDialog::Directory);
    fd.setOption(QFileDialog::ShowDirsOnly);
    fd.setViewMode(QFileDialog::Detail);

    int result = fd.exec();
    QString directory;
    if (result)
    {
        directory = fd.selectedFiles()[0];
        qDebug()<<directory;
    }

}

void MainWindow::on_pushButton_2_clicked()
{
    QFileFolderDialog dlgFileFolder;
    dlgFileFolder.setChosenFilePath(lastFilePath);
    int res = dlgFileFolder.exec();
    if(res == QDialog::Accepted)
    {
        //QString filePath = dlgFileFolder.getChosenFilePath();
        lastFilePath = dlgFileFolder.getChosenFilePath();
    }

    //QFileFolderDialog dialog();
    //dialog.exec();
}
