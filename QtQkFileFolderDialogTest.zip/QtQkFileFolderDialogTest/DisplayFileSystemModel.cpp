#include "DisplayFileSystemModel.h"


DisplayFileSystemModel::DisplayFileSystemModel(QObject *parent)
	: QFileSystemModel(parent)
{
	filtersNames["Directories only"] = static_cast<int>(QDir::NoDotAndDotDot | QDir::AllDirs);
	filtersNames["Files and folders"]= static_cast<int>(QDir::Filter::NoFilter);
}


//static inline QString permissionString(const QFileInfo &fi)
//static inline QString DisplayFileSystemModel::permissionString(const QFileInfo &fi)
QString DisplayFileSystemModel::permissionString(const QFileInfo &fi)
{
    const QFile::Permissions permissions = fi.permissions();
    QString result = QLatin1String("----------");
    if (fi.isSymLink())
        result[0] = QLatin1Char('l');
    else if (fi.isDir())
        result[0] = QLatin1Char('d');
    if (permissions & QFileDevice::ReadUser)
        result[1] = QLatin1Char('r');
    if (permissions & QFileDevice::WriteUser)
        result[2] = QLatin1Char('w');
    if (permissions & QFileDevice::ExeUser)
        result[3] = QLatin1Char('x');
    if (permissions & QFileDevice::ReadGroup)
        result[4] = QLatin1Char('r');
    if (permissions & QFileDevice::WriteGroup)
        result[5] = QLatin1Char('w');
    if (permissions & QFileDevice::ExeGroup)
        result[6] = QLatin1Char('x');
    if (permissions & QFileDevice::ReadOther)
        result[7] = QLatin1Char('r');
    if (permissions & QFileDevice::WriteOther)
        result[8] = QLatin1Char('w');
    if (permissions & QFileDevice::ExeOther)
        result[9] = QLatin1Char('x');
    return result;
}

//static inline QString sizeString(const QFileInfo &fi)
QString DisplayFileSystemModel::sizeString(const QFileInfo &fi)
{
    if (!fi.isFile())
        return QString();
    const qint64 size = fi.size();
    if (size > 1024 * 1024 * 10)
        return QString::number(size / (1024 * 1024)) + QLatin1Char('M');
    if (size > 1024 * 10)
        return QString::number(size / 1024) + QLatin1Char('K');
    return QString::number(size);
}


QVariant DisplayFileSystemModel::data(const QModelIndex &index, int role) const
{
    if (index.isValid() && role >= SizeRole) {
        switch (role) {
		case SizeRole:
		{
			//return QVariant(sizeString(fileInfo(index)));
			const QFileInfo fi = fileInfo(index);
			if (!fi.isFile())
				return QVariant( QString() );
			const qint64 size = fi.size();
			if (size > 1024 * 1024 * 10)
				return QVariant( QString::number(size / (1024 * 1024)) + QLatin1Char('M') );
			if (size > 1024 * 10)
				return QVariant( QString::number(size / 1024) + QLatin1Char('K') );
			return QVariant( QString::number(size) );
		}
		case DisplayableFilePermissionsRole:
		{
			//return QVariant(permissionString(fileInfo(index)));
			const QFileInfo &fi = fileInfo(index);

			const QFile::Permissions permissions = fi.permissions();
			QString result = QLatin1String("----------");
			if (fi.isSymLink())
				result[0] = QLatin1Char('l');
			else if (fi.isDir())
				result[0] = QLatin1Char('d');
			if (permissions & QFileDevice::ReadUser)
				result[1] = QLatin1Char('r');
			if (permissions & QFileDevice::WriteUser)
				result[2] = QLatin1Char('w');
			if (permissions & QFileDevice::ExeUser)
				result[3] = QLatin1Char('x');
			if (permissions & QFileDevice::ReadGroup)
				result[4] = QLatin1Char('r');
			if (permissions & QFileDevice::WriteGroup)
				result[5] = QLatin1Char('w');
			if (permissions & QFileDevice::ExeGroup)
				result[6] = QLatin1Char('x');
			if (permissions & QFileDevice::ReadOther)
				result[7] = QLatin1Char('r');
			if (permissions & QFileDevice::WriteOther)
				result[8] = QLatin1Char('w');
			if (permissions & QFileDevice::ExeOther)
				result[9] = QLatin1Char('x');
			return QVariant( result );
		}
        case LastModifiedRole:
            return QVariant(fileInfo(index).lastModified().toString(Qt::SystemLocaleShortDate));
        case UrlStringRole:
            return QVariant(QUrl::fromLocalFile(filePath(index)).toString());
        default:
            break;
        }
    }
    return QFileSystemModel::data(index, role);
}


void DisplayFileSystemModel::setQDirFilterFromInt(int iFilter)
{
	switch(iFilter)
	{
	case static_cast<int>(QDir::Filter::NoFilter):
		this->setFilter( QDir::Filter::NoFilter );
		break;
	case static_cast<int>(QDir::Filter::NoDotAndDotDot | QDir::Filter::AllDirs):
		this->setFilter( QDir::Filter::NoDotAndDotDot | QDir::Filter::AllDirs );
		break;
	case static_cast<int>(QDir::NoDotAndDotDot | QDir::Files):
		this->setFilter( QDir::NoDotAndDotDot | QDir::Files );
		break;
	default:
		this->setFilter( QDir::Filter::NoFilter );
		break;
	}

	/* // TO DO // Add more options if needed
		, static_cast<int>(QDir::Filter::Dirs           )
		, static_cast<int>(QDir::Filter::Files          )
		, static_cast<int>(QDir::Filter::Drives         )
		, static_cast<int>(QDir::Filter::NoSymLinks     )
		, static_cast<int>(QDir::Filter::AllEntries     )
		, static_cast<int>(QDir::Filter::TypeMask       )
		//static_cast<int>(,                            )
		, static_cast<int>(QDir::Filter::Readable       )
		, static_cast<int>(QDir::Filter::Writable       )
		, static_cast<int>(QDir::Filter::Executable     )
		, static_cast<int>(QDir::Filter::PermissionMask )
		//static_cast<int>(,                            )
		, static_cast<int>(QDir::Filter::Modified       )
		, static_cast<int>(QDir::Filter::Hidden         )
		, static_cast<int>(QDir::Filter::System         )
		, static_cast<int>(QDir::Filter::AccessMask     )
		, static_cast<int>(QDir::Filter::AllDirs        )
		, static_cast<int>(QDir::Filter::CaseSensitive  )
		, static_cast<int>(QDir::Filter::NoDot          )
		, static_cast<int>(QDir::Filter::NoDotDot       )
		, static_cast<int>(QDir::Filter::NoDotAndDotDot )
	*/
}

QHash<int,QByteArray> DisplayFileSystemModel::roleNames() const
{
     QHash<int, QByteArray> result = QFileSystemModel::roleNames();
     result.insert(SizeRole, QByteArrayLiteral("size"));
     result.insert(DisplayableFilePermissionsRole, QByteArrayLiteral("displayableFilePermissions"));
     result.insert(LastModifiedRole, QByteArrayLiteral("lastModified"));
     return result;
}


void DisplayFileSystemModel::setChosenFilePath(const QString &value)
{
	QString defalutPath = "C:/"; // TO DO //
	if(value.isEmpty())
	{
		chosenFilePath = defalutPath;
	}
	else // restore
	{
		chosenFilePath = value;
	}

	this->setRootPath(chosenFilePath);

	//ui->treeViewFolders->setColumnWidth(0, 230);

	// TO DO //
	if(chosenFilePath != defalutPath)
	{
		QModelIndex mindex = this->index(chosenFilePath);
		//ui->treeViewFolders->expand(mindex);
		//ui->treeViewFolders->scrollTo(mindex);
		//ui->treeViewFolders->setCurrentIndex(mindex);
		////ui->treeViewFolders->resizeColumnToContents(0); // Optional
	}


}


QString DisplayFileSystemModel::getChosenFilePath()
{
	return chosenFilePath;
}


void DisplayFileSystemModel::onCoboboxFileExtensionChanged(const QString &curFilterName)
{
	// Unit Tests
	//QString curFilterName = "Files and folders";
	//QString curFilterName = "Directories only";
	int iFilter = filtersNames[curFilterName];
	setQDirFilterFromInt(iFilter);
}

void DisplayFileSystemModel::isFileOrFolderExist(const QString &curFileOrFolderName)
{
	QFileInfo objectInfo( curFileOrFolderName );
	if (!objectInfo.exists())
	{
		QMessageBox::critical(  this
			, "Not found!"
			, "Chosen object does not exist!"
			);
		ui->editFullPath->setFocus();
	}

	return;
}



/*
void QFileFolderDialog::on_btnSelect_clicked()
{

}
*/


