#ifndef DISPLAY_FILE_SYS_MODEL_H
#define DISPLAY_FILE_SYS_MODEL_H

#include <QApplication>
#include <QGuiApplication>
#include <QQmlApplicationEngine>
#include <QQmlContext>
#include <QtQml>

#include <QFileSystemModel>
#include <QDateTime>
#include <QDesktopServices>
#include <QUrl>

class DisplayFileSystemModel : public QFileSystemModel
{
    Q_OBJECT
public:
	explicit DisplayFileSystemModel(QObject *parent = Q_NULLPTR);

	QString getChosenFilePath();
	Q_INVOKABLE void setChosenFilePath(const QString &value);
	Q_INVOKABLE void onCoboboxFileExtensionChanged(const QString &value);

    enum Roles  {
        SizeRole = Qt::UserRole + 4,
        DisplayableFilePermissionsRole = Qt::UserRole + 5,
        LastModifiedRole = Qt::UserRole + 6,
        UrlStringRole = Qt::UserRole + 7
    };
    Q_ENUM(Roles)

	QVariant data(const QModelIndex &index, int role = Qt::DisplayRole) const override;
	QHash<int,QByteArray> roleNames() const override;

private:
	QString chosenFilePath;

	void setQDirFilterFromInt(int iFilter);
	QMap<QString, int> filtersNames;

	QString permissionString(const QFileInfo &fi);
	QString sizeString(const QFileInfo &fi);

};


#endif // DISPLAY_FILE_SYS_MODEL_H
