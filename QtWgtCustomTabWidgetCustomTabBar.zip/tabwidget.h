#ifndef GUI_TABWIDGET_TABWIDGET_H
#define GUI_TABWIDGET_TABWIDGET_H

#include <QTabWidget>
#include <QTabBar>

class MyTabBar : public QTabBar
{
    Q_OBJECT
public:
    MyTabBar(QWidget *parent = nullptr);

protected:
    // void paintEvent(QPaintEvent *) override;
    void paintEvent(QPaintEvent *) override;
};

class MyTabWidget : public QTabWidget
{
    Q_OBJECT
public:
    explicit MyTabWidget(QWidget *parent = nullptr);

    // protected:
    //    void paintEvent(QPaintEvent *event);
};

#endif // GUI_TABWIDGET_TABWIDGET_H
