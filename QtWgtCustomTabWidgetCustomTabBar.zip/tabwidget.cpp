#include "tabwidget.h"
#include <QTabBar>
#include <QLabel>
//#include <gui/styleutils/reloadstylesheet.h>
#include <QPainter>
#include <QPixmap>
#include <QImage>

#include <QStylePainter>
#include <QStyleOptionTabBarBaseV2>
#include <QStyleOptionTabV3>
#include <QTabBar>
#include <QTabWidget>
#include <QFontMetrics>

MyTabBar::MyTabBar(QWidget *parent) : QTabBar(parent)
{
    // reloadStyleRecursive(this);
}

void MyTabBar::paintEvent(QPaintEvent *paintEvent)
{
    auto clr = this->palette().base().color();
    int  r   = clr.red();
    int  g   = clr.green();
    int  b   = clr.blue();

    QTabBar::paintEvent(paintEvent);
}

#if 0
// https://blog.titanwolf.in/a?ID=00350-7b765083-ae40-47ec-b447-b71a5abb9070
void MyTabBar::paintEvent(QPaintEvent *paintEvent)
{
    /*
    QPainter painter(this);
    QStyleOptionTabV2 option;
    for (int i = 0; i < this->count(); ++i) {
    initStyleOption(&option, i);
    //printf("tab text: %s\n", option.text.toLatin1().data());
    //painter.drawControl(QStyle::CE_TabBarTab, option);
    painter.drawItemPixmap(option.rect, 0, QPixmap("selected.png"));
    }
    */

    QTabBar::paintEvent(paintEvent);
    /*
    QPainter painter(this);
    auto     index = this->currentIndex();

    auto text = this->tabText(index);
    this->size();

    QRect iconRect = QRect(QPoint(0, 0), this->iconSize());

    const QRect &buttonWgt = tabRect(index);

    //auto buttonWgt = tabBar()->tabButton(0, QTabBar::ButtonPosition::LeftSide);
    //if (buttonWgt == nullptr)
    //    return QTabWidget::paintEvent(event);

    buttonWgt.x();
    buttonWgt.width();

    QFont        font("Ubuntu", 14);
    QFontMetrics font_metrics(font);
    int          pixelsHeigh = font_metrics.height();
    //double       pixelsWide  = (double)font_metrics.horizontalAdvance(text);
    double textWidth = (double)font_metrics.width(text);
    double xOffset   = 0.0;

    //xOffset = (buttonWgt.width() - pixelsWide) / 2.0;
    //xOffset = ((buttonWgt.width() / 2.0) - (textWidth / 2.0));
    //xOffset = ((buttonWgt.width() / 2.0) - (pixelsWide / 3.0));

    auto icon = this->tabIcon(this->currentIndex());
    //QRect rec();
    //icon.paint()
    //QPixmap pixmap = m_tablepic_.pixmap();
    QSize m_tablepic(20, 25);
    if (icon.isNull())
        return;
    const int iconSizeX = m_tablepic.width();  //GetSystemMetrics(SM_CXSMICON);
    const int iconSizeY = m_tablepic.height(); //GetSystemMetrics(SM_CYSMICON);
    QSize     size      = icon.actualSize(QSize(iconSizeX, iconSizeY));
    QImage    image     = icon.pixmap(size).toImage();

    QRect rectAdd(100, 100, m_tablepic.width(), m_tablepic.height());
    //QRect rectAdd(xOffset, rect().bottom() - m_tablepic.height() - 22, m_tablepic.width(), m_tablepic.height() - 5);
    //QRect rectAdd(0 + m_tablepic.width(), tabBar()->rect().bottom() - m_tablepic.height() - 22, m_tablepic.width(), m_tablepic.height() - 5);
    //QRect rectAdd(width() - m_tablepic.width(), tabBar()->rect().bottom() - m_tablepic.height() - 12, m_tablepic.width(), m_tablepic.height() - 5);
    //QRect rectAdd(width() - m_tablepic.width(), tabBar()->rect().bottom() - m_tablepic.height() + 7, m_tablepic.width(), m_tablepic.height() - 5);
    //int   w = (int)(buttonWgt.x() + xOffset);
    //QRect rectAdd(w - m_tablepic.width(), tabBar()->rect().bottom() - m_tablepic.height() + 7, m_tablepic.width(), m_tablepic.height() - 5);

    painter.drawImage(rectAdd, image);
    //painter.drawRect()
    //*/

    /*QPainter painter(this);

    QRect rectAdd(width() - m_tablepic.width(), tabBar()->rect().bottom() - m_tablepic.height() + 7, m_tablepic.width(),
                  m_tablepic.height() - 5);
    painter.drawImage(rectAdd, m_tablepic);
    */

    /*
    QPainter painter(this);
    auto     index    = this->currentIndex();
    auto     iconSize = this->iconSize();
    auto     text     = this->tabText(index);
    this->size();
    QRect iconRect = QRect(QPoint(0, 0), this->iconSize());
    auto  icon     = this->tabIcon(this->currentIndex());
    //QRect rec();
    //icon.paint()
    //QPixmap pixmap = m_tablepic_.pixmap();
    if (icon.isNull())
        return;
    QImage image = icon.pixmap(iconSize).toImage();

    QRect rectAdd(width() - iconSize.width(), this->rect().bottom() - iconSize.height() + 7, iconSize.width(), iconSize.height() - 5);

    painter.drawImage(rectAdd, image);
    //painter.drawRect()
    */

    /*
    TabWidget *tabWidget = (TabWidget *)this->parentWidget();

    //    switch (tabWidget->getTabFlag()) {
    //        case TabWidget::IconOverText: {

    QStylePainter painter(this);

    auto  index    = this->currentIndex();
    auto  tabSize  = this->tabRect(index);
    auto  iconSize = this->iconSize();
    auto  size     = this->size();
    auto  text     = this->tabText(index);
    auto  icon     = this->tabIcon(index);
    QRect iconRect = QRect(QPoint(0, 0), this->iconSize());

    for (int i = 0; i < this->count(); ++i) {
        QStyleOptionTab option;
        this->initStyleOption(&option, i);
        painter.drawItemPixmap(option.rect, Qt::AlignTop | Qt::AlignHCenter, option.icon.pixmap(QSize(16, 16)));
        //painter.drawItemText(option.rect, Qt::AlignBottom | Qt::AlignHCenter, this->palette(), 1, option.text);
        //painter.drawItemPixmap(option.rect, Qt::AlignJustify, option.icon.pixmap(this->iconSize()));
        painter.drawItemPixmap(QRect(50, 0, this->iconSize().width(), this->iconSize().height()), 0, option.icon.pixmap(this->iconSize()));
        auto geom = this->geometry();
        QPen penHLines(QColor("black"), 1, Qt::SolidLine, Qt::FlatCap, Qt::RoundJoin);
        painter.setPen(penHLines);
        //painter.drawLine(geom.x(), geom.y(), geom.x() + size.width() + 40, geom.y());
        //painter.drawRect(geom.x(), geom.y(), geom.x() + size.width() + 40, geom.y() + 1);

        // WORKING
        //QPalette palette(this->palette());
        //palette.setColor(QPalette::Highlight, QColor("white"));
        //painter.drawItemText(option.rect, Qt::AlignHCenter, palette, 1, option.text);
    }
    //            break;
    //        }
    //        default:

    //QTabBar::paintEvent(paintEvent);
    //            break;
    //    }
    //*/

    /*
    QStyleOption opt;
    opt.init(this);
    QPainter p(this);
    //style()->drawPrimitive(QStyle::PE_Widget, &opt, &p, this);                                                              //Draw the base
    //style()->drawItemText(&p, this->rect(), Qt::AlignCenter, (this->palette()), true, this->tabText(this->currentIndex())); //Draw the text

    //How do I make the image immediately follow the text
    //style()->drawItemPixmap(&p, );
    //style()->drawItemPixmap(&p, this->rect(), Qt::AlignRight | Qt::AlignVCenter, this->icon().pixmap(this->rect().height() * 0.75));
    //auto icon = this->tabIcon(this->currentIndex());
    //if (!icon.isNull()) //Draw the icon at 75% button height
    //    style()->drawItemPixmap(&p, this->rect(), Qt::AlignRight | Qt::AlignVCenter, icon.pixmap(this->rect().height() * 0.75));
    //style()->drawItemPixmap(&p, this->rect(), Qt::AlignRight | Qt::AlignVCenter, this->tabIcon(this->currentIndex()).pixmap(this->rect().height() * 0.75));
    style()->drawItemPixmap(&p, this->rect(), Qt::AlignRight | Qt::AlignVCenter, QPixmap(":/gui/images/icon_usb_2.png"));
    //*/

    QStylePainter stlpainter(this);
    for (int i = 0; i < this->count(); ++i) {

        int   picSize = 20;
        auto  text    = this->tabText(i);
        QFont font("Ubuntu", 12);
        font.setBold(true);
        QFontMetrics font_metrics(font);
        int          pixelsHeigh = font_metrics.height();
        //double       pixelsWide  = (double)font_metrics.horizontalAdvance(text);
        double textWidth = (double)font_metrics.width(text);
        double xOffset   = 0.0;

        //xOffset = (buttonWgt.width() - pixelsWide) / 2.0;
        xOffset = ((this->tabRect(i).width() / 2.0) - (textWidth / 2.0)) - picSize;
        //xOffset = ((this->tabRect(i).width() / 2.0) - (pixelsWide / 3.0));

        int wwidth = 0;
        for (int j = 0; j < i; ++j) {
            wwidth += this->tabRect(j).width(); //auto            index = this->currentIndex();
        }
        QStyleOptionTab option;
        this->initStyleOption(&option, i);
        QString picString;
        switch (i) {
            case 0:
                picString = ":/gui/images/icon_usb.png";
                break;
            case 1:
                picString = ":/gui/images/icon_usb_2.png";
                break;
            case 2:
                picString = ":/gui/images/icon_usb_pressed.png";
                break;
        }
        QPixmap pic(picString);
        QPixmap picScaled = pic.scaled(QSize(picSize, picSize), Qt::IgnoreAspectRatio, Qt::SmoothTransformation);
        stlpainter.drawItemPixmap(QRect(wwidth + xOffset, (this->tabRect(i).height() / 2.0) - (picSize / 2.0), picSize, picSize), 0, picScaled);
    }
}
#endif

MyTabWidget::MyTabWidget(QWidget *parent) : QTabWidget(parent)
{
    setTabBar(new MyTabBar(this));
}

#if 0
void MyTabWidget::paintEvent(QPaintEvent *event)
{
    //*
    QTabWidget::paintEvent(event);
/*
    QPainter painter(this);
    QStyleOptionTabV2 option;
    initStyleOption(&option, i);
    //printf("tab text: %s\n", option.text.toLatin1().data());
    //painter.drawControl(QStyle::CE_TabBarTab, option);
    painter.drawItemPixmap(option.rect, 0, QPixmap("selected.png"));

    /*
    QPainter painter(this);
    auto     index = this->currentIndex();

    auto text = this->tabText(index);
    this->size();

    QRect iconRect = QRect(QPoint(0, 0), this->iconSize());

    const QRect &buttonWgt = tabBar()->tabRect(index);

    //auto buttonWgt = tabBar()->tabButton(0, QTabBar::ButtonPosition::LeftSide);
    //if (buttonWgt == nullptr)
    //    return QTabWidget::paintEvent(event);

    buttonWgt.x();
    buttonWgt.width();

    QFont        font("Ubuntu", 14);
    QFontMetrics font_metrics(font);
    int          pixelsHeigh = font_metrics.height();
    double       pixelsWide  = (double)font_metrics.horizontalAdvance(text);
    double       textWidth   = (double)font_metrics.width(text);
    double       xOffset     = 0.0;

    //xOffset = (buttonWgt.width() - pixelsWide) / 2.0;
    //xOffset = ((buttonWgt.width() / 2.0) - (textWidth / 2.0));
    xOffset = ((buttonWgt.width() / 2.0) - (pixelsWide / 3.0));

    auto icon = this->tabIcon(this->currentIndex());
    //QRect rec();
    //icon.paint()
    //QPixmap pixmap = m_tablepic_.pixmap();
    QSize m_tablepic(20, 25);
    if (icon.isNull())
        return;
    const int iconSizeX = m_tablepic.width();  //GetSystemMetrics(SM_CXSMICON);
    const int iconSizeY = m_tablepic.height(); //GetSystemMetrics(SM_CYSMICON);
    QSize     size      = icon.actualSize(QSize(iconSizeX, iconSizeY));
    QImage    image     = icon.pixmap(size).toImage();

    QRect rectAdd(xOffset, tabBar()->rect().bottom() - m_tablepic.height() - 22, m_tablepic.width(), m_tablepic.height() - 5);
    //QRect rectAdd(0 + m_tablepic.width(), tabBar()->rect().bottom() - m_tablepic.height() - 22, m_tablepic.width(), m_tablepic.height() - 5);
    //QRect rectAdd(width() - m_tablepic.width(), tabBar()->rect().bottom() - m_tablepic.height() - 12, m_tablepic.width(), m_tablepic.height() - 5);
    //QRect rectAdd(width() - m_tablepic.width(), tabBar()->rect().bottom() - m_tablepic.height() + 7, m_tablepic.width(), m_tablepic.height() - 5);
    //int   w = (int)(buttonWgt.x() + xOffset);
    //QRect rectAdd(w - m_tablepic.width(), tabBar()->rect().bottom() - m_tablepic.height() + 7, m_tablepic.width(), m_tablepic.height() - 5);

    painter.drawImage(rectAdd, image);
    //painter.drawRect()
    //*/
}
#endif
