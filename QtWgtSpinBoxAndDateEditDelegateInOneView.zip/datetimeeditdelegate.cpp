#include "DateTimeEditDelegate.h"

DateTimeEditDelegate::DateTimeEditDelegate(QObject *parent) :
    QItemDelegate(parent)
{
}


QWidget* DateTimeEditDelegate::createEditor(QWidget *parent, const QStyleOptionViewItem &option, const QModelIndex &index) const
{
    QDateTimeEdit *editor = new QDateTimeEdit(parent);
    editor->setDisplayFormat("dd.MM.yyyy HH:mm:ss");
    return editor;
}

void DateTimeEditDelegate::setEditorData(QWidget *editor, const QModelIndex &index) const
{
//    int value = index.model()->data(index, Qt::EditRole).toInt();
//    QSpinBox *spinbox = static_cast<QSpinBox*>(editor);
//    spinbox->setValue(value);

    QString strDate = index.model()->data(index, Qt::EditRole).toString();
    QDateTime dtm = QDateTime::fromString( strDate , "dd.MM.yyyy HH:mm:ss");

    if(dtm.isValid())
    {
        QDateTimeEdit *dtmEdit = static_cast<QDateTimeEdit*>(editor);
        dtmEdit->setDateTime(dtm);
    }
}

void DateTimeEditDelegate::setModelData(QWidget *editor, QAbstractItemModel *model, const QModelIndex &index) const
{
    QDateTimeEdit *spinbox = static_cast<QDateTimeEdit*>(editor);
    spinbox->interpretText();
    //int value = spinbox->value();
    //QString strDate = index.model()->data(index, Qt::EditRole).toString();
    QString strDate = spinbox->dateTime().toString("dd.MM.yyyy HH:mm:ss");
    QDateTime dtm = QDateTime::fromString( strDate , "dd.MM.yyyy HH:mm:ss");

    if(dtm.isValid())
    {
        model->setData(index, strDate, Qt::EditRole);
    }

/*
    QDateTimeEdit *spinbox = static_cast<QDateTimeEdit*>(editor);
    spinbox->interpretText();
    //int value = spinbox->value();
    QString strDate = index.model()->data(index, Qt::EditRole).toString();
    QDateTime dtm = QDateTime::fromString( strDate , "dd.MM.yyyy HH:mm:ss");

    model->setData(index, strDate, Qt::EditRole);
*/
}

void DateTimeEditDelegate::updateEditorGeometry(QWidget *editor,const QStyleOptionViewItem &option,const QModelIndex &index) const
{
    editor->setGeometry(option.rect);
}


