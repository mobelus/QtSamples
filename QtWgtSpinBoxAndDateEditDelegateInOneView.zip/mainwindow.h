#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QtGui>
#include <QStandardItemModel>

#include "delegate.h"
#include "DateTimeEditDelegate.h"

namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

    QStandardItemModel *model;
    SpinBoxDelegate *myDelegate_1;
    DateTimeEditDelegate *myDelegate_2;

private:
    Ui::MainWindow *ui;


};

#endif // MAINWINDOW_H
