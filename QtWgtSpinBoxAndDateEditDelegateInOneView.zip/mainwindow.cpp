#include "mainwindow.h"
#include "ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    model = new QStandardItemModel(4,2,this);
    myDelegate_1 = new SpinBoxDelegate;
    myDelegate_2 = new DateTimeEditDelegate;

    for(int row=0; row < 4; ++row)
    {
        for(int col=0; col < 3; ++col)
        {
            QModelIndex index = model->index(row, col, QModelIndex());

//            if(col == 0 )
//                model->setData(index, "23:59:59 31.12.2020");
//            else
                model->setData(index, 0);
        }
    }

    ui->tableView->setModel(model);

//    ui->tableView->setItemDelegate(myDelegate);
    ui->tableView->setItemDelegateForColumn(0, myDelegate_1);
    ui->tableView->setItemDelegateForColumn(1, myDelegate_2);

    ui->tableView->setColumnWidth(0, 200);
    ui->tableView->setColumnWidth(1, 200);

}

MainWindow::~MainWindow()
{
    delete ui;
}
