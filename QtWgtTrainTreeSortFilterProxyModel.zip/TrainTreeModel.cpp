#include "TrainTreeModel.h"

#include "ScheduleDatetypes.h"

#include <QJsonDocument>
#include <QJsonObject>
#include <QJsonArray>

namespace schedulemodel
{
	TrainTreeModel::TrainTreeModel(QObject* parent) : QAbstractItemModel(parent)
	{
		
	}


	TrainTreeModel::~TrainTreeModel()
	{
		delete _rootItem;
		_rootItem = nullptr;
	}



	bool TrainTreeModel::saveJsonObjectToFile(const QJsonObject& rootTag, const QString& fileName)
	{
		bool res = false;

		QString filePathSave = fileName;
		QJsonDocument doc(rootTag);
		QFile oFile(filePathSave);
		res = oFile.open(QFile::ReadWrite);
		if (res)
		{
			res = (oFile.write(doc.toJson())) > 0;
			oFile.close();
		}

		return res;
	}


	bool TrainTreeModel::save(QJsonObject& schedule, QString* error)
	{
		QJsonObject rootTag;
		QJsonArray routesArr;

//		Root,
//		Route,
//		Train,
//		Station

		for (int i = 0, ichildren = _rootItem->childCount(); i < ichildren; ++i)
		{
			ScheduleModelItem* routeItem = _rootItem->getChild(i);
			RouteItem* route = dynamic_cast<RouteItem*>(routeItem);

			int routeId  = 0,  trainId = 0, stationId = 0;
			QString routeDscr, trainDscr, stationDscr, name, ar, dep;

			routeId = route->id();
			routeDscr = route->description();

			QJsonObject currentRoute;
			QJsonArray trainsArr;

			for (int r = 0, rchildren = routeItem->childCount(); r < rchildren; ++r)
			{
				ScheduleModelItem* trainItem = routeItem->getChild(r);
				TrainItem* train = dynamic_cast<TrainItem*>(trainItem);

				trainId = train->id();
				trainDscr = train->description();

				QJsonObject trainJson;
				QJsonArray stopsArr;
				QString currTrainNumString;

				for (int t = 0, tchildren = trainItem->childCount(); t < tchildren; ++t)
				{
					ScheduleModelItem* stationItem = trainItem->getChild(t);
					StationItem* station = dynamic_cast<StationItem*>(stationItem);

					stationItem->type();
					stationItem->id();
					stationItem->description();

					stationId = station->id();
					stationDscr = station->description();

					name = station->_name;
					ar   = station->_arrival.toString(DateTimeFormatFrom);
					dep  = station->_depature.toString(DateTimeFormatFrom);

					//StationScheduleInfo& currentScheduleElemTmp = _itemsShown[j];

					QJsonObject tagObj;
					currTrainNumString      = QString::number(trainId);
					tagObj["stationId"]     = QString::number(stationId);
					tagObj["station"]       = name;
					tagObj["timeArrival"]   = ar;
					tagObj["timeDeparture"] = dep;

					stopsArr.append(tagObj);
				}

				trainJson.insert("trainNumber", currTrainNumString);
				trainJson.insert("stops", stopsArr);
				trainsArr.append(trainJson);
			}

			currentRoute["routeNumber"] = QString::number(routeId); //QString::number(currentRouteNum);
			currentRoute["trains"] = trainsArr;
			//
			routesArr << currentRoute;

		}
		rootTag.insert("time-interval-system", routesArr);
		
		schedule = rootTag;
		//
		//return rootTag;

		return true;


		//int children = _rootItem->childCount();
		//getChild

		/*
		QString localErr;
		for (int i = 0; i < routesArr.size(); ++i)
		{
			ScheduleModelItem* routeItem = new RouteItem(_rootItem);
			res = routeItem->load(routesArr[i].toObject(), &localErr);

			if (!res)
			{
				delete routeItem;
				if (error)
					*error = localErr;
				break;
			}
			else
			{
				_rootItem->addChild(routeItem);
			}
		}
		*/
	}

	bool TrainTreeModel::load(const QJsonObject& schedule, QString* error)
	{		
		if (schedule.isEmpty())
		{
			return false;
		}

		bool res = false;
		QJsonValue value = schedule.value(QString("time-interval-system"));
		QJsonArray routesArr = value.toArray();

		beginResetModel();
		
		_rootItem = new ScheduleModelItem(nullptr);
		QString localErr;
		for (int i = 0; i < routesArr.size(); ++i)
		{			
			ScheduleModelItem* routeItem = new RouteItem(_rootItem);
			res = routeItem->load(routesArr[i].toObject(), &localErr);

			if (!res)
			{
				delete routeItem;
				if (error)
					*error = localErr;
				break;
			}
			else
			{
				_rootItem->addChild(routeItem);
			}
		}
		
		endResetModel();

		return res;
	}


	Qt::ItemFlags TrainTreeModel::flags(const QModelIndex &index) const
	{
		Qt::ItemFlags theFlags = QAbstractItemModel::flags(index);
		if (index.isValid()) 
		{
			theFlags |= Qt::ItemIsSelectable | Qt::ItemIsEnabled;
			ScheduleModelItem* currItem = itemForIndex(index);
			if (currItem)
			{
				if (ScheduleModelItem::ElemType::Station == currItem->type() 
					&& (index.column() == TrainTreeModel::Columns::DateTimeArrival 
					|| index.column() == TrainTreeModel::Columns::DateTimeDepature) )
				{
					theFlags |= Qt::ItemIsEditable;
				}
			}
		}
		return theFlags;
	}


	ScheduleModelItem* TrainTreeModel::itemForIndex(const QModelIndex &index) const
	{
		ScheduleModelItem* item = nullptr;
		if (index.isValid())
		{
			if (ScheduleModelItem *item = static_cast<ScheduleModelItem*>(index.internalPointer()))
				return item;
		}
		else
		{
			item = _rootItem;
		}
		return item;
	}


	QVariant TrainTreeModel::data(const QModelIndex &index, int role) const
	{
		if (!_rootItem || !index.isValid() || index.column() < 0 || index.column() >= ColumnCount)
			return QVariant();

		if (ScheduleModelItem *item = itemForIndex(index)) 
		{
			if (role == Qt::DisplayRole )
			{
				switch (index.column())
				{
					case Columns::ScheduleItemType:  return item->id(); // TODO
					case Columns::ScheduleItemDescr: return item->description(); // TODO (we don't have any kind of description)					
					default: break;
				}
			}


			if (role == Qt::DisplayRole || role == Qt::EditRole)
			{
				switch (index.column())
				{
					case Columns::DateTimeArrival:
					{
						if (item->type() == ScheduleModelItem::ElemType::Station)
						{
							auto staionItem = static_cast<StationItem*>(item);
							return staionItem->_arrival.toString(schedulemodel::DateTimeFormatTo);
						}
					}
					case Columns::DateTimeDepature:
					{
						if (item->type() == ScheduleModelItem::ElemType::Station)
						{
							auto staionItem = static_cast<StationItem*>(item);
							return staionItem->_depature.toString(schedulemodel::DateTimeFormatTo);
						}
					}
					default: break;
				}
			}
		}
		return QVariant();
	}


	QVariant TrainTreeModel::headerData(int section, Qt::Orientation orientation, int role) const
	{
		if (orientation == Qt::Horizontal && role == Qt::DisplayRole)
		{
			// TODO Need to make a const reference for this or something like that
			if (section == Columns::ScheduleItemType)
				return tr("Route/Train/Station"); 
			else if (section == Columns::ScheduleItemDescr)
				return tr("Description");
			else if (section == Columns::DateTimeArrival)
				return tr("Arrival datetime");
			else if (section == Columns::DateTimeDepature)
				return tr("Departure datetime");
		}
		return QVariant();
	}



	bool TrainTreeModel::setData(const QModelIndex &index, const QVariant &value, int role)
	{
		if (!index.isValid())
			return false;
		ScheduleModelItem* item = itemForIndex(index);
		if ( item  &&  (item->type() == ScheduleModelItem::ElemType::Station)  &&  (role == Qt::EditRole) )
		{
			auto stationItem = static_cast<StationItem*>(item);
			if (index.column() == Columns::DateTimeArrival)
			{
				stationItem->_arrival = QDateTime::fromString(value.toString(), schedulemodel::DateTimeFormatTo);
				qDebug() << "Arrival time" << stationItem->_arrival;
			}
			else if (index.column() == Columns::DateTimeDepature)
			{
				QString tmpVal = value.toString();
				stationItem->_depature = QDateTime::fromString(value.toString(), schedulemodel::DateTimeFormatTo);
				qDebug() << "Departure time" << stationItem->_depature;
			}
			else
			{
				return false;
			}

			emit dataChanged(index, index);
			return true;
		}
		return false;
	}


	int TrainTreeModel::rowCount(const QModelIndex &parent) const
	{
		if (parent.isValid() && parent.column() != 0)
		{
			return 0;
		}

		ScheduleModelItem* parentItem = itemForIndex(parent);
		return parentItem ? parentItem->childCount() : 0;
	}


	int TrainTreeModel::columnCount(const QModelIndex &parent) const
	{
		return parent.isValid() && parent.column() != 0 ? 0 : ColumnCount;
	}


	QModelIndex TrainTreeModel::index(int row, int column,	const QModelIndex &parent) const
	{
		if (!_rootItem || row < 0 || column < 0 || column >= ColumnCount 
			|| (parent.isValid() && parent.column() != 0))
		{
			return QModelIndex();
		}

		ScheduleModelItem* parentItem = itemForIndex(parent);
		assert(parentItem);

		QModelIndex resIndex;
		ScheduleModelItem *item = parentItem->getChild(row);
		if (item)
		{
			resIndex = createIndex(row, column, item);
		}
		return resIndex;
	}


	QModelIndex TrainTreeModel::parent(const QModelIndex &index) const
	{
		if (!index.isValid())
		{
			return QModelIndex();
		}
		
		if (ScheduleModelItem* currentItem = itemForIndex(index)) 
		{
			if (ScheduleModelItem* parentItem = currentItem->getParent())
			{
				if (parentItem == _rootItem)
				{
					return QModelIndex();
				}
				// here we need to find place where parent element of our element (currentItem) is located concerning his parent 
				if (ScheduleModelItem* grandParentItem = parentItem->getParent())
				{
					int row = grandParentItem->getChildPosition(parentItem);
					return createIndex(row, 0, parentItem);
				}
			}
		}
		return QModelIndex();
	}


	void TrainTreeModel::clear()
	{
		beginResetModel();
		delete _rootItem;
		_rootItem = nullptr;
		endResetModel();
	}

}


