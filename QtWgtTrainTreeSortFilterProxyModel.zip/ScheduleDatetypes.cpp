#include "ScheduleDatetypes.h"


namespace schedulemodel
{

	const char* const StationID			 = "stationId";
	const char* const StationName		 = "station";
	const char* const StationDescription = "stationDescription";
	const char* const StationArrivial	 = "timeArrival";
	const char* const StationDepature	 = "timeDeparture";
	//
	const char* const TrainNumber		 = "trainNumber";
	const char* const TrainDescription	 = "trainDescription";
	const char* const TrainStops		 = "stops";
	//
	const char* const RouteNumber		 = "routeNumber";
	const char* const RouteDescription	 = "routeDescription";
	const char* const TrainsInRoute		 = "trains";



	ScheduleModelItem::ScheduleModelItem(ScheduleModelItem* parent )
	{
		_rootItem = parent;
		_type = ScheduleModelItem::ElemType::Root;
	}

	ScheduleModelItem::~ScheduleModelItem()
	{
		qDeleteAll(_data);
		_data.clear();
	}

	bool ScheduleModelItem::load(const QJsonObject& trainItem, QString* error )
	{
		if (error)
		{
			*error = QString(" TO DO ");
			return false;
		}

		return true;
	}
	//virtual QJsonObject save(QString* error = nullptr) const = 0;

	int ScheduleModelItem::childCount() const
	{
		return _data.size();
	}

	ScheduleModelItem* ScheduleModelItem::getChild(int i) const
	{
		//return _data.value(i);
		ScheduleModelItem* child = nullptr;
		if (i >= 0 && i < _data.size())
			child = _data[i];
		return child;
	}

	void ScheduleModelItem::addChild(ScheduleModelItem*  child)
	{
		_data.push_back(child);
	}

	int ScheduleModelItem::getChildPosition(ScheduleModelItem * const child) const
	{
		return _data.indexOf(child);
	}


	ScheduleModelItem* ScheduleModelItem::getParent() const
	{
		return _rootItem;
	}

	//
	//
	//


	StationItem::StationItem(ScheduleModelItem* parent )
		: ScheduleModelItem(parent)
	{
		_type = ScheduleModelItem::ElemType::Station;
	}

	bool StationItem::load(const QJsonObject& stationItem, QString* error ) 
	{
		bool res = false;
		if (!stationItem.isEmpty())
		{			
			QJsonValue jStationId    = stationItem[StationID];
			QJsonValue jStationName  = stationItem[StationName];
			QJsonValue jStationName_ = stationItem[StationName];

			QJsonValue jArrival		 = stationItem[StationArrivial];
			QJsonValue jDeparture	 = stationItem[StationDepature];

			_id			 = jStationId.toString().toInt();
			_name		 = jStationName.toString();
			_arrival	 = QDateTime::fromString(jArrival.toString().trimmed(), DateTimeFormatFrom);
			_depature	 = QDateTime::fromString(jDeparture.toString().trimmed(), DateTimeFormatFrom);
			//_description = QObject::tr("station");
			_description = jStationName_.toString();

			res = true;
		}
		else
		{
			if (error)
				*error = "Empty json to initialize station item";
		}

		return res;
	}


	QJsonObject StationItem::save() const
	{
		// TO DO 
		QJsonObject obj;

		return obj;
	}



	//bool operator == (const StationItem& lhs, const StationItem& rhs)
	//{
	//	return ((lhs._id == rhs._id) && (lhs._name == rhs._name) &&
	//		(lhs._arrival == rhs._arrival) &&
	//		(lhs._depature == rhs._depature));
	//}



	//template <typename ChildElement>
	//class RootScheduleElement : public ScheduleModelItem
	//{	
	//public:
	//	virtual bool load(const QJsonObject& trainItem, QString* error = nullptr) = 0;
	//	virtual bool loadChilds(const QJsonArray& childItems, QString* error = nullptr)
	//	{
	//		for (int i = 0; i < childItems.size(); ++i)
	//		{
	//			ChildElement newItem;
	//			if (newItem.load(childItems[i].toObject(), &err))
	//			{
	//				_childs.push_back(newItem);
	//			}
	//			else
	//			{
	//				if (error)
	//					*error = err;
	//				break;
	//			}
	//		}
	//	}
	//};
	

	TrainItem::TrainItem(ScheduleModelItem* parent ) : ScheduleModelItem(parent)
	{
		_type = ScheduleModelItem::ElemType::Train;
	}

	bool TrainItem::load(const QJsonObject& trainItem, QString* error ) 
	{
		bool res = false;
		QString err;

		if (!trainItem.isEmpty())
		{
			_id = trainItem[TrainNumber].toString().toInt();
			_description = QObject::tr("train");//trainItem[TrainDescription].toString();

			QJsonArray stationItems = trainItem[TrainStops].toArray();

			for (int i = 0; i < stationItems.size(); ++i)
			{
				ScheduleModelItem* newItem = new StationItem(this);
				res = newItem->load(stationItems[i].toObject(), &err);
				if (res)
				{
					_data.push_back(newItem);
				}
				else
				{
					delete newItem;
					if (error)
						*error = err;
					break;
				}
			}
		}
		else
		{
			if (error)
				*error = "Empty json to initialize train item";
		}
		//
		return res;
	}

	//
	//
	//

	RouteItem::RouteItem(ScheduleModelItem* parent ) : ScheduleModelItem(parent)
	{
		_type = ScheduleModelItem::ElemType::Route;			
	}

	bool RouteItem::load(const QJsonObject& routeItem, QString* error ) 
	{
		bool res = false;
		QString err;

		if (!routeItem.isEmpty())
		{
			_id			 = routeItem[RouteNumber].toString().toInt();
			_description = QObject::tr("route"); //routeItem[RouteDescription].toString();

			QJsonArray trainItems = routeItem[TrainsInRoute].toArray();

			for (int i = 0; i < trainItems.size(); ++i)
			{
				ScheduleModelItem* newItem = new TrainItem(this);
				res = newItem->load(trainItems[i].toObject(), &err);
				if (res)
				{
					_data.push_back(newItem);
				}
				else
				{
					delete newItem;
					if (error)
						*error = err;
					break;
				}
			}
		}
		else
		{
			if (error)
				*error = "Empty json to initialize route item";
		}
		//
		return res;
	}



} // schedulemodel