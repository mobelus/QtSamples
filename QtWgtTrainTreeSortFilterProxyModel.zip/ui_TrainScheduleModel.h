/********************************************************************************
** Form generated from reading UI file 'TrainScheduleModel.ui'
**
** Created by: Qt User Interface Compiler version 5.12.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_TRAINSCHEDULEMODEL_H
#define UI_TRAINSCHEDULEMODEL_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QCheckBox>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QToolBar>
#include <QtWidgets/QTreeView>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_TrainScheduleModelClass
{
public:
    QWidget *centralWidget;
    QVBoxLayout *verticalLayout;
    QHBoxLayout *horizontalLayout;
    QPushButton *button;
    QLabel *label;
    QLineEdit *lineEditRoute;
    QCheckBox *isRoute;
    QLabel *label_2;
    QLineEdit *lineEditTrain;
    QPushButton *pushButtonFilter;
    QPushButton *pushButtonSave;
    QTreeView *treeView;
    QMenuBar *menuBar;
    QToolBar *mainToolBar;
    QStatusBar *statusBar;

    void setupUi(QMainWindow *TrainScheduleModelClass)
    {
        if (TrainScheduleModelClass->objectName().isEmpty())
            TrainScheduleModelClass->setObjectName(QString::fromUtf8("TrainScheduleModelClass"));
        TrainScheduleModelClass->resize(841, 732);
        centralWidget = new QWidget(TrainScheduleModelClass);
        centralWidget->setObjectName(QString::fromUtf8("centralWidget"));
        verticalLayout = new QVBoxLayout(centralWidget);
        verticalLayout->setSpacing(6);
        verticalLayout->setContentsMargins(11, 11, 11, 11);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setSpacing(6);
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        button = new QPushButton(centralWidget);
        button->setObjectName(QString::fromUtf8("button"));

        horizontalLayout->addWidget(button);

        label = new QLabel(centralWidget);
        label->setObjectName(QString::fromUtf8("label"));

        horizontalLayout->addWidget(label);

        lineEditRoute = new QLineEdit(centralWidget);
        lineEditRoute->setObjectName(QString::fromUtf8("lineEditRoute"));

        horizontalLayout->addWidget(lineEditRoute);

        isRoute = new QCheckBox(centralWidget);
        isRoute->setObjectName(QString::fromUtf8("isRoute"));

        horizontalLayout->addWidget(isRoute);

        label_2 = new QLabel(centralWidget);
        label_2->setObjectName(QString::fromUtf8("label_2"));

        horizontalLayout->addWidget(label_2);

        lineEditTrain = new QLineEdit(centralWidget);
        lineEditTrain->setObjectName(QString::fromUtf8("lineEditTrain"));

        horizontalLayout->addWidget(lineEditTrain);

        pushButtonFilter = new QPushButton(centralWidget);
        pushButtonFilter->setObjectName(QString::fromUtf8("pushButtonFilter"));

        horizontalLayout->addWidget(pushButtonFilter);

        pushButtonSave = new QPushButton(centralWidget);
        pushButtonSave->setObjectName(QString::fromUtf8("pushButtonSave"));

        horizontalLayout->addWidget(pushButtonSave);


        verticalLayout->addLayout(horizontalLayout);

        treeView = new QTreeView(centralWidget);
        treeView->setObjectName(QString::fromUtf8("treeView"));

        verticalLayout->addWidget(treeView);

        TrainScheduleModelClass->setCentralWidget(centralWidget);
        menuBar = new QMenuBar(TrainScheduleModelClass);
        menuBar->setObjectName(QString::fromUtf8("menuBar"));
        menuBar->setGeometry(QRect(0, 0, 841, 21));
        TrainScheduleModelClass->setMenuBar(menuBar);
        mainToolBar = new QToolBar(TrainScheduleModelClass);
        mainToolBar->setObjectName(QString::fromUtf8("mainToolBar"));
        TrainScheduleModelClass->addToolBar(Qt::TopToolBarArea, mainToolBar);
        statusBar = new QStatusBar(TrainScheduleModelClass);
        statusBar->setObjectName(QString::fromUtf8("statusBar"));
        TrainScheduleModelClass->setStatusBar(statusBar);

        retranslateUi(TrainScheduleModelClass);

        QMetaObject::connectSlotsByName(TrainScheduleModelClass);
    } // setupUi

    void retranslateUi(QMainWindow *TrainScheduleModelClass)
    {
        TrainScheduleModelClass->setWindowTitle(QApplication::translate("TrainScheduleModelClass", "TrainScheduleModel", nullptr));
        button->setText(QApplication::translate("TrainScheduleModelClass", "Load from File", nullptr));
        label->setText(QApplication::translate("TrainScheduleModelClass", " Route ", nullptr));
        isRoute->setText(QApplication::translate("TrainScheduleModelClass", "is Route  ", nullptr));
        label_2->setText(QApplication::translate("TrainScheduleModelClass", " Train ", nullptr));
        pushButtonFilter->setText(QApplication::translate("TrainScheduleModelClass", "Filter", nullptr));
        pushButtonSave->setText(QApplication::translate("TrainScheduleModelClass", "SaveFile", nullptr));
    } // retranslateUi

};

namespace Ui {
    class TrainScheduleModelClass: public Ui_TrainScheduleModelClass {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_TRAINSCHEDULEMODEL_H
