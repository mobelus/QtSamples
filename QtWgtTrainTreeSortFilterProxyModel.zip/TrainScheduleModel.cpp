#include "TrainScheduleModel.h"

#include "TrainTreeModel.h"


#include <QFile>
#include <QJsonObject>
#include <QJsonDocument>
#include <QJsonParseError>
#include <QDebug>

using namespace schedulemodel;

TrainScheduleModel::TrainScheduleModel(QWidget *parent)
	: QMainWindow(parent)
{
	ui.setupUi(this);

	connect(ui.pushButtonFilter, SIGNAL(clicked()), this, SLOT(onSave()));
	connect(ui.lineEditRoute, SIGNAL(textChanged(const QString &)), this, SLOT( onLineEditRouteTextChanged(const QString &)) );
	connect(ui.lineEditTrain, SIGNAL(textChanged(const QString &)), this, SLOT( onLineEditTrainTextChanged(const QString &)) );
	connect(ui.isRoute,		  SIGNAL(stateChanged(int)),			this, SLOT( onCheckBoxRouteStateChanged(int)) );

	onCheckBoxRouteStateChanged(0);
}



void TrainScheduleModel::onCheckBoxRouteStateChanged(int b)
{
	Q_UNUSED(b);

	if (ui.isRoute->isChecked())
	{
		_proxyModel->enableSortByRoute();
	}
	else
	{
		_proxyModel->enableSortByRouteAndTrain();
	}

	//QString routeNum = ui.lineEditRoute->text();
	//QRegExp regExp(str, Qt::CaseInsensitive, QRegExp::PatternSyntax::FixedString);
	//proxyModel->setFilterRegExp(regExp);
}


void TrainScheduleModel::onLineEditRouteTextChanged(const QString &str)
{
	QString routeNum = ui.lineEditRoute->text();

	QRegExp regExp( str, Qt::CaseInsensitive, QRegExp::PatternSyntax::FixedString );

	//proxyModel->setFilterRegExpForRoute(regExp);

	_proxyModel->setFilterRouteNumber(routeNum);
	
	//proxyModel->modelReset();
	//proxyModel->sourceModelChanged();
	_proxyModel->setFilterRegExp(QRegExp());
}

void TrainScheduleModel::onLineEditTrainTextChanged(const QString &str)
{
	QString routeNum = ui.lineEditRoute->text();
	QString trainNum = ui.lineEditTrain->text();

	QRegExp regExpRoute( routeNum, Qt::CaseInsensitive, QRegExp::PatternSyntax::FixedString);
	QRegExp regExpTrain( trainNum, Qt::CaseInsensitive, QRegExp::PatternSyntax::FixedString);

	//proxyModel->setFilterRegExpForRouteAndTrain(regExpRoute, regExpTrain);

	_proxyModel->setFilterRouteAndTrainNumber(routeNum, trainNum);

	_proxyModel->setFilterRegExp(QRegExp());
}


void TrainScheduleModel::onSave()
{
	//QJsonObject ourScheduleJson = stationScheduleTableModel->saveToJsonObject();
	QString err;
	QJsonObject ourScheduleJson;
	bool res = _model->save(ourScheduleJson, &err);

	if (!ourScheduleJson.isEmpty())
	{
		_model->saveJsonObjectToFile(ourScheduleJson, "_FuckinSchedule.txt");
	}
	else
	{
		//logInfo("Error: Unable to create Json to send it to Database!");
	}
}

/*
void TrainScheduleModel::onSave()
{
	QString err;
	QJsonObject obj;
	
	_model->save(obj, &err);

	//QJsonDocument doc = QJsonDocument::fromJson(scheduleFile.readAll(), &err);
	//if (err.error != QJsonParseError::NoError)
}
*/

void TrainScheduleModel::load()
{
	QString schedulePath = QString("schedule.json");
	QFile scheduleFile(schedulePath);

	if (!scheduleFile.open(QIODevice::ReadOnly | QIODevice::Text))
	{
		qDebug() << "Can't open file" << scheduleFile.errorString();
		return;
	}
	else
	{
		QJsonParseError err;
		QJsonDocument doc = QJsonDocument::fromJson(scheduleFile.readAll(), &err);
		if (err.error != QJsonParseError::NoError)
		{
			qDebug() << "Wrong file, error: " << err.errorString();
			return;
		}
		else
		{
			_model = new schedulemodel::TrainTreeModel();
			_model->load(doc.object());

			//ui.treeView->setModel(model);
			//ui.treeView->update();

			_proxyModel = new TrainTreeSortFilterProxyModel(this);
			_proxyModel->setSourceModel( _model );

			ui.treeView->setRootIsDecorated(false);
			ui.treeView->setAlternatingRowColors(true);
			ui.treeView->setModel( _proxyModel );
//			ui.treeView->setSortingEnabled(true);
//			ui.treeView->sortByColumn(1, Qt::AscendingOrder);

		}
	}
}
