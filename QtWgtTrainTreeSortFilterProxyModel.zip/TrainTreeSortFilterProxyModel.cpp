#include <QtWidgets>

#include "TrainTreeSortFilterProxyModel.h"
#include "ScheduleDatetypes.h"

TrainTreeSortFilterProxyModel::TrainTreeSortFilterProxyModel(QObject *parent)
    : QSortFilterProxyModel(parent)
{
	isSortingByRoute = true;
}


void TrainTreeSortFilterProxyModel::enableSortByRoute()
{
	isSortingByRoute = true;
}


void TrainTreeSortFilterProxyModel::enableSortByRouteAndTrain()
{
	isSortingByRoute = false;
}

void TrainTreeSortFilterProxyModel::setFilterRouteNumber(QString r)
{
	_r = r;
	_t.clear();
}

void TrainTreeSortFilterProxyModel::setFilterRouteAndTrainNumber(QString r, QString t)
{
	_r = r;
	_t = t;
}


bool TrainTreeSortFilterProxyModel::filterAcceptsRow(int source_row, const QModelIndex &source_parent) const
{
#if 0
	QModelIndex index_00 = sourceModel()->index(0, 0, source_parent);
	QModelIndex index_01 = sourceModel()->index(0, 1, source_parent);
	QModelIndex index_02 = sourceModel()->index(0, 2, source_parent);
	QModelIndex index_03 = sourceModel()->index(0, 3, source_parent);

	QModelIndex index_10 = sourceModel()->index(1, 0, source_parent);
	QModelIndex index_11 = sourceModel()->index(1, 1, source_parent);
	QModelIndex index_12 = sourceModel()->index(1, 2, source_parent);
	QModelIndex index_13 = sourceModel()->index(1, 3, source_parent);

	QModelIndex index_0  = sourceModel()->index(0, 0, source_parent);
//	QModelIndex index_1 = sourceModel()->index(source_row, 1, source_parent);
//	QModelIndex index_2 = sourceModel()->index(source_row, 2, source_parent);

	{
		QVariant value_00 = index_00.data(0);
		if (value_00.isValid()) {
			QString s_ = value_00.toString();
		}
		QVariant value_01 = index_01.data(0);
		if (value_01.isValid()) {
			QString s_ = value_01.toString();
		}
		QVariant value_02 = index_02.data(0);
		if (value_02.isValid()) {
			QString s_ = value_02.toString();
		}
		QVariant value_03 = index_03.data(0);
		if (value_03.isValid()) {
			QString s_ = value_03.toString();
		}

		QVariant value_10 = index_10.data(0);
		if (value_10.isValid()) {
			QString s_ = value_10.toString();
		}
		QVariant value_11 = index_11.data(0);
		if (value_11.isValid()) {
			QString s_ = value_11.toString();
		}
		QVariant value_12 = index_12.data(0);
		if (value_12.isValid()) {
			QString s_ = value_12.toString();
		}
		QVariant value_13 = index_13.data(0);
		if (value_13.isValid()) {
			QString s_ = value_13.toString();
		}


		/*
		QVariant value_0 = index_0.data(0);

		QVariant value_1 = index_1.data(0);
		if (value_1.isValid()) {
			int n_ = value_1.toInt();
			QString s_ = value_1.toString();
		}

		QVariant value_2 = index_2.data(0);
		if (value_0.isValid()) {
			int n_ = value_2.toInt();
			QString s_ = value_2.toString();
		}
		*/
	}

/* ////////////////////////////////////////////////
	QVariant value0 = source_parent.data(0);
	if (value0.isValid()) {
		int n0 = value0.toInt();
		QString s0 = value0.toString();

		//if(s0 == _r)
	}

	QVariant value1 = source_parent.data(1);
	if (value1.isValid()) {
		int n1 = value1.toInt();
		QString s1 = value1.toString();
	}

	QVariant value2 = source_parent.data(2);
	if(value2.isValid()) {
		int n2 = value2.toInt();
		QString s2 = value2.toString();
	}
	int z = 0;
*/ ////////////////////////////////////////////////////

	//QModelIndex index1 = sourceModel()->index(source_row, 1, source_parent);
	//QModelIndex index2 = sourceModel()->index(source_row, 2, source_parent);

	QString s = sourceModel()->data(index_0).toString();

#endif

	if ( /*!isSortingByRoute &&*/ !_r.isEmpty() && !_t.isEmpty() )
	{
		QModelIndex itemIndex = sourceModel()->index(source_row, 0, source_parent);
		if (!itemIndex.isValid())
			return false;
		auto itemOriginal = static_cast<schedulemodel::ScheduleModelItem*>(itemIndex.internalPointer());

		switch (itemOriginal->type())
		{
		case schedulemodel::ScheduleModelItem::ElemType::Route:
		{
			if (_r.toInt() != itemOriginal->id())
				return false;
		}
		break;
		case schedulemodel::ScheduleModelItem::ElemType::Train:
		{
			if (   _r.toInt() != itemOriginal->getParent()->id()
				|| _t.toInt() != itemOriginal->id()
				)
			{
				return false;
			}
		}
		break;
		case schedulemodel::ScheduleModelItem::ElemType::Station:
		{
			if (   _r.toInt() != itemOriginal->getParent()->getParent()->id()
				|| _t.toInt() != itemOriginal->getParent()->id()
				)
			{
				return false;
			}
		}
		break;
		default:
			break;
		}
	}

	if ( /*isSortingByRoute &&*/ !_r.isEmpty() && _t.isEmpty() )
	{
		QModelIndex itemIndex = sourceModel()->index(source_row, 0, source_parent);
		if (!itemIndex.isValid())
			return false;
		auto itemOriginal = static_cast<schedulemodel::ScheduleModelItem*>(itemIndex.internalPointer());

		switch (itemOriginal->type())
		{
		case schedulemodel::ScheduleModelItem::ElemType::Route:
		{
			if (_r.toInt() != itemOriginal->id())
				return false;
		}
		break;
		case schedulemodel::ScheduleModelItem::ElemType::Train:
		{
			if (_r.toInt() != itemOriginal->getParent()->id())
				return false;
		}
		break;
		case schedulemodel::ScheduleModelItem::ElemType::Station:
		{
			if (_r.toInt() != itemOriginal->getParent()->getParent()->id())
				return false;
		}
		break;
		default:
			break;
		}
	}


	QModelIndex itemIndex = sourceModel()->index(source_row, 0, source_parent);

	return sourceModel()->data(itemIndex).toString().contains(QRegExp());

#if 0
	return
	(
		sourceModel()->data( index_0 ).toString().contains(QRegExp())
/*
		(isSortingByRoute)
		?
		//sourceModel()->data(index0).toString().contains(_regexpRoute)
		sourceModel()->data(index0).toString().contains( filterRegExp() )
		:
		(
				sourceModel()->data(index0).toString().contains(_regexpRoute)
		//	&&	sourceModel()->data(index1).toString().contains(_regexpTrain)
		  )
*/
	);
#endif

	//		|| sourceModel()->data(index1).toString().contains(filterRegExp()))
	//		&& dateInRange(sourceModel()->data(index2).toDate()

}

/*
bool TrainTreeSortFilterProxyModel::lessThan(const QModelIndex &left,
                                      const QModelIndex &right) const
{
    QVariant leftData = sourceModel()->data(left);
    QVariant rightData = sourceModel()->data(right);

    if (leftData.type() == QVariant::DateTime)
    {
        return leftData.toDateTime() < rightData.toDateTime();
    }
    else
    {
        static const QRegularExpression emailPattern("[\\w\\.]*@[\\w\\.]*");

        QString leftString = leftData.toString();
        if (left.column() == 1)
        {
            const QRegularExpressionMatch match = emailPattern.match(leftString);
            if (match.hasMatch())
                leftString = match.captured(0);
        }
        QString rightString = rightData.toString();
        if (right.column() == 1)
        {
            const QRegularExpressionMatch match = emailPattern.match(rightString);
            if (match.hasMatch())
                rightString = match.captured(0);
        }

        return QString::localeAwareCompare(leftString, rightString) < 0;
    }
}

bool TrainTreeSortFilterProxyModel::dateInRange(const QDate &date) const
{
    return ( !minDate.isValid() || date > minDate)
            && (!maxDate.isValid() || date < maxDate);
}
*/
