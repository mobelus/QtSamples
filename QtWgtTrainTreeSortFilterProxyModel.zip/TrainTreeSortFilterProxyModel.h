#ifndef TRAINSORTFILTERPROXYMODEL_H
#define TRAINSORTFILTERPROXYMODEL_H

#include <QDate>
#include <QSortFilterProxyModel>

class TrainTreeSortFilterProxyModel : public QSortFilterProxyModel
{
    Q_OBJECT

public:
	TrainTreeSortFilterProxyModel(QObject *parent = 0);

	void enableSortByRoute();
	void enableSortByRouteAndTrain();

	void setFilterRouteNumber(QString r);
	void setFilterRouteAndTrainNumber(QString r, QString t);

protected:
	bool filterAcceptsRow(int sourceRow, const QModelIndex &sourceParent) const override;

private:
	bool isSortingByRoute;

	QString _r;
	QString _t;
};

#endif // TRAINSORTFILTERPROXYMODEL_H
