#pragma once

#include <QtWidgets/QMainWindow>
#include "ui_TrainScheduleModel.h"
#include "TrainTreeSortFilterProxyModel.h"

namespace schedulemodel
{
	class TrainTreeModel;
}

class TrainScheduleModel : public QMainWindow
{
	Q_OBJECT

public slots:
	void onLineEditRouteTextChanged(const QString &str);
	void onLineEditTrainTextChanged(const QString &str);
	void onCheckBoxRouteStateChanged(int b);
	void onSave();

public:
	TrainScheduleModel(QWidget *parent = Q_NULLPTR);
	void load();
	void save();

private:
	Ui::TrainScheduleModelClass ui;

	schedulemodel::TrainTreeModel* _model;
	TrainTreeSortFilterProxyModel *_proxyModel;

};
