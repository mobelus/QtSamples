#pragma once


#include <QAbstractItemModel>






namespace schedulemodel
{
	class ScheduleModelItem;


	class TrainTreeModel : public QAbstractItemModel
	{
		Q_OBJECT

		enum Columns
		{
			ScheduleItemType = 0,
			ScheduleItemDescr,  
			DateTimeArrival,
			DateTimeDepature
		};


	public:
		TrainTreeModel(QObject* parent = nullptr);
		virtual ~TrainTreeModel();


		Qt::ItemFlags flags(const QModelIndex &index) const;
		QVariant data(const QModelIndex &index,	int role = Qt::DisplayRole) const;
		QVariant headerData(int section, Qt::Orientation orientation, int role = Qt::DisplayRole) const;

		bool setData(const QModelIndex &index, const QVariant &value, int role);

		int rowCount(const QModelIndex &parent = QModelIndex()) const;
		int columnCount(const QModelIndex &parent = QModelIndex()) const;
		
		QModelIndex index(int row, int column, const QModelIndex &parent = QModelIndex()) const;
		QModelIndex parent(const QModelIndex &index) const;

		void clear();
		bool load(const QJsonObject& schedule, QString* error = nullptr);
		bool save(QJsonObject& schedule, QString* error = nullptr);

		bool saveJsonObjectToFile(const QJsonObject& rootTag, const QString& fileName);

	private:
		ScheduleModelItem* itemForIndex(const QModelIndex &index) const;		

	private:
		ScheduleModelItem* _rootItem;
		//
		const int ColumnCount = 4;
	};


}

