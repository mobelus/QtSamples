#pragma once


#include <QString>
#include <QDateTime>
#include <QJsonObject>
#include <QJsonArray>
#include <QVector>
#include <QList>

#include <QDebug>


namespace schedulemodel
{
	//
	const char* const DateTimeFormatTo = "hh:mm:ss dd.MM.yyyy";
	const char* const DateTimeFormatFrom = "yyyy-MM-ddThh:mm:ss";
	const char* const IntermediateFormat = "yyyy-MM-ddThh:mm:ss.zzz";


	class ScheduleModelItem
	{
	public:
		enum class ElemType
		{
			Root,
			Route,
			Train,
			Station
		};

		ScheduleModelItem(ScheduleModelItem* parent = nullptr);

		~ScheduleModelItem();

		virtual bool load(const QJsonObject& trainItem, QString* error = nullptr);
		//virtual QJsonObject save(QString* error = nullptr) const = 0;

		int childCount() const;

		ScheduleModelItem* getChild(int i) const;

		void addChild(ScheduleModelItem* const child);

		int getChildPosition(ScheduleModelItem * const child) const;


		ScheduleModelItem* getParent() const;


		ElemType type() const { return _type; }
		int id() const		  { return _id; };
		QString description() const { return _description; }


	protected:
		ElemType					_type;
		ScheduleModelItem*			_rootItem;
		QList<ScheduleModelItem*>	_data;
		//
		int			_id;
		QString		_description;
	};



	class StationItem : public ScheduleModelItem
	{
	public:
		StationItem(ScheduleModelItem* parent = nullptr);

		bool load(const QJsonObject& stationItem, QString* error = nullptr) override;

		QJsonObject save() const;
		
		//
		QString		_name;
		QDateTime	_arrival;
		QDateTime	_depature;
	};


	class TrainItem : public ScheduleModelItem
	{
	public:
		TrainItem(ScheduleModelItem* parent = nullptr);

		bool load(const QJsonObject& trainItem, QString* error = nullptr) override;
	};



	class RouteItem : public ScheduleModelItem
	{
	public:
		RouteItem(ScheduleModelItem* parent = nullptr);

		bool load(const QJsonObject& routeItem, QString* error = nullptr) override;
	};





} // schedulemodel