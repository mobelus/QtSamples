#include "mainwindow.h"
#include "ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);

	ui->TimePicker->setTime(ui->TimeEdit->time());

	connect(ui->TimePicker, SIGNAL(timePicked(QTime)), ui->TimeEdit, SLOT(setTime(QTime)));
	connect(ui->TimeEdit, SIGNAL(timeChanged(QTime)), ui->TimePicker, SLOT(setTime(QTime)));
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::changeEvent(QEvent *e)
{
    QWidget::changeEvent(e);
    switch (e->type()) {
    case QEvent::LanguageChange:
        ui->retranslateUi(this);
        break;
    default:
        break;
    }
}
