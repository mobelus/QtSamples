#include "paintscheme.h"


namespace QSint
{


PaintScheme::PaintScheme()
{
    basePen = QPen(Qt::gray);
    baseBrush = QBrush(Qt::lightGray);
}


}

