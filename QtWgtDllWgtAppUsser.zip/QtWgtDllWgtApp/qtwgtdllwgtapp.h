#ifndef QTWGTDLLWGTAPP_H
#define QTWGTDLLWGTAPP_H

#include "qtwgtdllwgtapp_global.h"

class QTWGTDLLWGTAPPSHARED_EXPORT QtWgtDllWgtApp
{

public:
	QtWgtDllWgtApp();

	void test() const;
};

#endif // QTWGTDLLWGTAPP_H
