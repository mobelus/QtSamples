#include "qtwgtdllwgtapp.h"

#include <QDebug>

QtWgtDllWgtApp::QtWgtDllWgtApp()
{
}


void QtWgtDllWgtApp::test() const
{
	qDebug() << "test";
}


