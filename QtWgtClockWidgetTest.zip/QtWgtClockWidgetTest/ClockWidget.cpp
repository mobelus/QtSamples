#include "ClockWidget.h"
#include "ui_ClockWidget.h"


ClockWidget::ClockWidget(QWidget *parent)
	: QWidget(parent)
	, ui(new Ui::ClockWidget)
	, _timer(new QTimer(this))
{
	ui->setupUi(this);

	_timer->setInterval(500);
	_timer->setSingleShot(false);
	_timer->start();

	connect(_timer, &QTimer::timeout,
		this, &ClockWidget::updateTime);
}


ClockWidget::~ClockWidget()
{
	delete ui;
}


void ClockWidget::updateTime()
{
	auto dateTime = QDateTime::currentDateTime();
	ui->labelTime->setText(dateTime.toString("hh:mm:ss"));
	ui->labelDate->setText(dateTime.toString("dd.MM.yyyy"));
}