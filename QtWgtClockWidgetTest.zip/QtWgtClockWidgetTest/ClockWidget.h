#ifndef CLOCKWIDGET_H
#define CLOCKWIDGET_H

#include <QWidget>
#include <QTimer>
#include <QDateTime>

namespace Ui {
	class ClockWidget;
}

class ClockWidget : public QWidget
{
	Q_OBJECT

public:
	explicit ClockWidget(QWidget *parent = nullptr);
	~ClockWidget();

public slots:
	void updateTime();

private:
	Ui::ClockWidget * ui;
	QTimer * _timer;
};

#endif // CLOCKWIDGET_H