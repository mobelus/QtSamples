#include "CredentialWidget.h"
#include "ui_CredentialWidget.h"

const int INFO_SHOW_SEC = 5;
const int LOGOUT_SHOW_SEC = 9;
const int TIMER_TICK_MILSEC = 1000;



CredentialWidget::CredentialWidget(QWidget *parent)
	: QWidget(parent)
	, ui(new Ui::CredentialWidget)
	//, _dialog(new LoginLogoutDlg(this))
	, _messageBoxLogout(/*new QMessageBox(QMessageBox::Question, tr("Logout user"), tr("Confirm logout operation?"), QMessageBox::NoButton, this)*/nullptr)
	, _messageBoxLogoutAccept(nullptr)
	, _messageBoxLogoutReject(nullptr)
	, _logoutRejectSec(0)
	, _messageBoxInfo(/*new QMessageBox(QMessageBox::Information, tr("Logout user"), tr("Server sent a command to logout"), QMessageBox::NoButton, this)*/nullptr)
	, _messageBoxInfoAccept(nullptr)
	, _infoRejectSec(0)
	, _timer(new QTimer(this))
	//, _state(CredentialManager::State::NoConnection)
	, _hideLogoutInfo(false)
{
	ui->setupUi(this);
	//ui->logoutButton->setVisible(false);

	//ui->loginButton->setEnabled(false);

	//connect(_dialog, &LoginLogoutDlg::loginRequest, this, &CredentialWidget::loginRequest);
	//connect(this, &CredentialWidget::stateChanged, _dialog, &LoginLogoutDlg::onStateChanged);

	connect(_timer, &QTimer::timeout, this, &CredentialWidget::onTimerTick);

	//connect(_dialog, &LoginLogoutDlg::getDlgCenterCoordsOnAppScreen, this, &CredentialWidget::getDlgCenterCoordsOnAppScreen);
	//connect(_dialog, &LoginLogoutDlg::usersListRequest,  this, &CredentialWidget::usersListRequest);
	//connect(this, &CredentialWidget::usersListResponse, _dialog, &LoginLogoutDlg::onSetUsersList);
	//connect(this, &CredentialWidget::sendCenterCoordsForDlg, _dialog, &LoginLogoutDlg::onSetThisDlgInCenterOfAppScreen);

	//connect(_dialog, &LoginLogoutDlg::rejected, this, &CredentialWidget::onCancelLoginLogoutTextCommand);


	//_messageBoxLogoutAccept = _messageBoxLogout->addButton(tr("Logout"), QMessageBox::AcceptRole);
	//
	//connect(_messageBoxLogoutAccept, &QPushButton::clicked,
	//		this, &CredentialWidget::logoutRequest);
	//
	//_messageBoxLogoutReject = _messageBoxLogout->addButton(tr("Stay"), QMessageBox::RejectRole);
	retranslateUi();

	_timer->setInterval(TIMER_TICK_MILSEC);
	_timer->setSingleShot(false);
	_timer->stop();
}



CredentialWidget::~CredentialWidget()
{
	delete ui;
}



void CredentialWidget::retranslateUi()
{
	ui->retranslateUi(this);
/*
	if (_state != CredentialManager::State::Authorized)
		ui->labelRole->setText(tr("guest"));

	_dialog->retranslateUi();
*/
	if (_messageBoxLogout)
		delete _messageBoxLogout;

	if (_messageBoxInfo)
		delete _messageBoxInfo;

	_messageBoxLogout = new QMessageBox(QMessageBox::Question, tr("Logout user"), tr("Confirm logout operation?"), QMessageBox::NoButton, this);
	_messageBoxInfo = new QMessageBox(QMessageBox::Information, tr("Logout user"), tr("Server sent a command to logout"), QMessageBox::NoButton, this);

	_messageBoxLogoutAccept = _messageBoxLogout->addButton(tr("Logout"), QMessageBox::AcceptRole);
	_messageBoxLogoutReject = _messageBoxLogout->addButton(tr("Stay"), QMessageBox::RejectRole);

	_messageBoxInfoAccept = _messageBoxInfo->addButton(tr("OK"), QMessageBox::AcceptRole);

	connect(_messageBoxLogoutAccept, &QPushButton::clicked, this, &CredentialWidget::logoutRequest);
	connect(_messageBoxLogoutReject, &QPushButton::clicked, this, &CredentialWidget::onCancelLoginLogoutTextCommand);
}



void CredentialWidget::setCredential(const QString & userFIO, const QString & userLogin)
{
	ui->labelUser->setText(userFIO);
	ui->labelRole->setText(userLogin);
}

void CredentialWidget::onSetCredential(/*CredentialManager::State state,*/ const QString & userFIO, const QString & userLogin/*,
									 const QString & guiOptions, const QByteArray & guiUserOptions*/)
{
	setCredential(userFIO, userLogin);

/*
	if (state == CredentialManager::State::Authorized)
	{
		ui->labelUser->setText(userName);
		ui->labelRole->setText(userRole);

		//ui->loginButton->setVisible(false);
		//ui->logoutButton->setVisible(true);
	}
	else if (state == CredentialManager::State::Unauthorized
		|| state == CredentialManager::State::NoConnection)
	{
		ui->labelUser->setText(tr(""));
		ui->labelRole->setText(tr("guest"));

		//ui->loginButton->setVisible(true);
		//ui->logoutButton->setVisible(false);
	}

	ui->loginButton->setEnabled(state != CredentialManager::State::NoConnection);

	if (state == CredentialManager::State::NoConnection)
	{
		_messageBoxLogout->reject();
	}

	if ((_state == CredentialManager::State::Authorized)
			&& (state == CredentialManager::State::Unauthorized))
	{
		_messageBoxLogout->reject();

		if (!_hideLogoutInfo)
		{
			_infoRejectSec = INFO_SHOW_SEC;
			_updateInfo();
			_messageBoxInfo->show();
			_timer->start();
		}
	}
//*/
	_hideLogoutInfo = false;

	//_state = state;

	//emit stateChanged(_state);
}



void CredentialWidget::onTimerTick()
{
	if (_infoRejectSec > 0)
	{
		_infoRejectSec --;
		_updateInfo();
	}
	if (_infoRejectSec == 0)
	{
		if (_messageBoxInfo->isVisible())
		{
			_messageBoxInfo->reject();
		}
	}

	if (_logoutRejectSec > 0)
	{
		_logoutRejectSec --;
		_updateLogout();
	}
	if (_logoutRejectSec == 0)
	{
		if (_messageBoxLogout->isVisible())
		{
			_messageBoxLogout->reject();
		}
	}

	if (( ! _messageBoxInfo->isVisible())
			&& ( ! _messageBoxLogout->isVisible()))
	{
		_timer->stop();
	}

}



void CredentialWidget::on_loginButton_clicked()
{
#ifdef Q_OS_ANDROID
	emit loginRequest("dsp1", "123456", true);
	return;
#endif

//	_dialog->reset();
//	_dialog->show();
}



void CredentialWidget::on_logoutButton_clicked()
{
#ifdef Q_OS_ANDROID
	emit logoutRequest();
	return;
#endif

	_logoutRejectSec = LOGOUT_SHOW_SEC;
	_updateLogout();
	_messageBoxLogout->show();
	_timer->start();

	_hideLogoutInfo = true;
}


void CredentialWidget::onPerformLogoutTextCommand()
{
/*
	if(ui->logoutButton->isVisible())
	{
		emit on_logoutButton_clicked();
	}
	else
	{
		emit performLogoutTextCommandRes(CredentialManager::State::UnavailableLogout, "", "", "", "");
	}
*/
}

void CredentialWidget::onPerformLoginTextCommand()
{
/*
	if (ui->loginButton->isVisible())
	{
		emit on_loginButton_clicked();
	}
	else
	{
		emit performLoginTextCommandRes(CredentialManager::State::UnavailableLogin, "", "", "", "");
	}
*/
}

void CredentialWidget::onPerformLoginForcedTextCommand()
{
/*
	if (ui->loginButton->isVisible())
	{
		emit on_loginButton_clicked();
		_dialog->enableForceLogin();
	}
	else
	{
		emit performLoginTextCommandRes(CredentialManager::State::UnavailableLogin, "", "", "", "");
	}
*/
}

void CredentialWidget::onCancelLoginLogoutTextCommand()
{
//	emit performLogoutTextCommandCancel(CredentialManager::State::LoginLogoutCancelled, "", "", "", "");
}




void CredentialWidget::_updateInfo()
{
	_messageBoxInfoAccept->setText(tr("OK") + " (" + QString::number(_infoRejectSec) + ")");
}



void CredentialWidget::_updateLogout()
{
	_messageBoxLogoutReject->setText(tr("Stay") + " (" + QString::number(_logoutRejectSec) + ")");
}
