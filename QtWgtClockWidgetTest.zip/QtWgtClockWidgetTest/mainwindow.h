#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>

#include <QSpacerItem>
#include <QHBoxLayout>

#include <QLabel>

#include <QSharedPointer>
#include "ClockWidget.h"

#include "CredentialWidget.h"

namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
	Q_OBJECT

public:
	explicit MainWindow(QWidget *parent = nullptr);
	~MainWindow();

private:
	Ui::MainWindow *ui;

	//QScopedPointer<QSpacerItem> _spacerHor;
	QScopedPointer<ClockWidget> _clockWidget;
	QScopedPointer<CredentialWidget> _credentialWidget;

};

#endif // MAINWINDOW_H
