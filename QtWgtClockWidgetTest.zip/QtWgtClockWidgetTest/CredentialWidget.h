#ifndef CREDENTIALWIDGET_H
#define CREDENTIALWIDGET_H

#include <QWidget>
#include <QMessageBox>

#include <QPushButton>
#include <QTimer>

//#include <HMICore.h>

//#include "CredentialManager.h"
//#include "LoginLogoutDialog.h"

namespace Ui {
class CredentialWidget;
}

class CredentialWidget : public QWidget
{
	Q_OBJECT

public:
	explicit CredentialWidget(QWidget *parent = nullptr);
	~CredentialWidget();

	void retranslateUi();

	void setCredential(const QString & userFIO, const QString & userLogin);

signals:
	void loginRequest(const QString & userName, const QString & password, bool force);
	void logoutRequest();
	//void stateChanged(CredentialManager::State state);
	
	void usersListRequest();
	void usersListResponse(QStringList users);
	void getDlgCenterCoordsOnAppScreen(QRect dlgSize);
	void sendCenterCoordsForDlg(QRect loginDlg);
	//void performLogoutTextCommandRes(CredentialManager::State state, const QString & userName, const QString & userRole, const QString & guiOptions, const QByteArray & guiUserOptions);
	//void performLogoutTextCommandCancel(CredentialManager::State state, const QString & userName, const QString & userRole, const QString & guiOptions, const QByteArray & guiUserOptions);
	//void performLoginTextCommandRes(CredentialManager::State state, const QString & userName, const QString & userRole, const QString & guiOptions, const QByteArray & guiUserOptions);
	//void performLoginTextCommandCancel(CredentialManager::State state, const QString & userName, const QString & userRole, const QString & guiOptions, const QByteArray & guiUserOptions);

public slots:
	void onSetCredential(/*CredentialManager::State state,*/ const QString & userFIO, const QString & userLogin/*,
					   const QString & guiOptions, const QByteArray & guiUserOptions*/);
	void onPerformLogoutTextCommand();
	void onPerformLoginTextCommand();
	void onPerformLoginForcedTextCommand();
	void onCancelLoginLogoutTextCommand();

private slots:
	void onTimerTick();

	void on_loginButton_clicked();
	void on_logoutButton_clicked();

private:
	void _updateInfo();
	void _updateLogout();

	Ui::CredentialWidget * ui;
	//LoginLogoutDlg * _dialog;
	QMessageBox * _messageBoxLogout;
	QPushButton * _messageBoxLogoutAccept;
	QPushButton * _messageBoxLogoutReject;
	int _logoutRejectSec;
	QMessageBox * _messageBoxInfo;
	QPushButton * _messageBoxInfoAccept;
	int _infoRejectSec;
	QTimer * _timer;
	//CredentialManager::State _state;
	bool _hideLogoutInfo;
};

#endif // CREDENTIALWIDGET_H
