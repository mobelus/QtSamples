#include "mainwindow.h"
#include "ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent) :
	QMainWindow(parent)
	,ui(new Ui::MainWindow)
	,_clockWidget(new ClockWidget(this))
	,_credentialWidget(new CredentialWidget(this))
{
	ui->setupUi(this);

	//QHBoxLayout *hlayout = new QHBoxLayout;
	//QSpacerItem* _spacerHor = (new QSpacerItem(1,1, QSizePolicy::Expanding, QSizePolicy::Fixed));
	//hlayout->addSpacerItem(_spacerHor);
	//ui->statusBar->addWidget(hlayout);

/*
	_credentialWidget->setCredential("Иванов Сергей Иванович", "isivan");
	ui->statusBar->addWidget(_credentialWidget.data());
	//ui->mainToolBar->addWidget(_clockWidget.data());
	ui->statusBar->addWidget(_clockWidget.data());
*/

	ui->statusBar->addPermanentWidget(new QLabel("",this));
	_credentialWidget->setCredential("Иванов Сергей Иванович", "isivan");
	ui->statusBar->addPermanentWidget(_credentialWidget.data());
	ui->statusBar->addPermanentWidget(_clockWidget.data());
}

MainWindow::~MainWindow()
{
	delete ui;
}
