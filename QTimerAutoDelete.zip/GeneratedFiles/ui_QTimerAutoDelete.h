/********************************************************************************
** Form generated from reading UI file 'QTimerAutoDelete.ui'
**
** Created by: Qt User Interface Compiler version 5.9.6
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_QTIMERAUTODELETE_H
#define UI_QTIMERAUTODELETE_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QCheckBox>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QToolBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_QTimerAutoDeleteClass
{
public:
    QWidget *centralWidget;
    QPushButton *pushButton;
    QLabel *label;
    QCheckBox *checkBox;
    QMenuBar *menuBar;
    QToolBar *mainToolBar;
    QStatusBar *statusBar;

    void setupUi(QMainWindow *QTimerAutoDeleteClass)
    {
        if (QTimerAutoDeleteClass->objectName().isEmpty())
            QTimerAutoDeleteClass->setObjectName(QStringLiteral("QTimerAutoDeleteClass"));
        QTimerAutoDeleteClass->resize(600, 400);
        centralWidget = new QWidget(QTimerAutoDeleteClass);
        centralWidget->setObjectName(QStringLiteral("centralWidget"));
        pushButton = new QPushButton(centralWidget);
        pushButton->setObjectName(QStringLiteral("pushButton"));
        pushButton->setGeometry(QRect(100, 90, 351, 23));
        label = new QLabel(centralWidget);
        label->setObjectName(QStringLiteral("label"));
        label->setGeometry(QRect(100, 160, 351, 51));
        label->setFrameShape(QFrame::StyledPanel);
        checkBox = new QCheckBox(centralWidget);
        checkBox->setObjectName(QStringLiteral("checkBox"));
        checkBox->setGeometry(QRect(100, 40, 351, 17));
        QTimerAutoDeleteClass->setCentralWidget(centralWidget);
        menuBar = new QMenuBar(QTimerAutoDeleteClass);
        menuBar->setObjectName(QStringLiteral("menuBar"));
        menuBar->setGeometry(QRect(0, 0, 600, 21));
        QTimerAutoDeleteClass->setMenuBar(menuBar);
        mainToolBar = new QToolBar(QTimerAutoDeleteClass);
        mainToolBar->setObjectName(QStringLiteral("mainToolBar"));
        QTimerAutoDeleteClass->addToolBar(Qt::TopToolBarArea, mainToolBar);
        statusBar = new QStatusBar(QTimerAutoDeleteClass);
        statusBar->setObjectName(QStringLiteral("statusBar"));
        QTimerAutoDeleteClass->setStatusBar(statusBar);

        retranslateUi(QTimerAutoDeleteClass);

        QMetaObject::connectSlotsByName(QTimerAutoDeleteClass);
    } // setupUi

    void retranslateUi(QMainWindow *QTimerAutoDeleteClass)
    {
        QTimerAutoDeleteClass->setWindowTitle(QApplication::translate("QTimerAutoDeleteClass", "QTimerAutoDelete", Q_NULLPTR));
        pushButton->setText(QApplication::translate("QTimerAutoDeleteClass", "Press me to test auto deletion of an object in QSharedPointer", Q_NULLPTR));
        label->setText(QString());
        checkBox->setText(QApplication::translate("QTimerAutoDeleteClass", "Use timer", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class QTimerAutoDeleteClass: public Ui_QTimerAutoDeleteClass {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_QTIMERAUTODELETE_H
