#include <QThread>

#include "QTimerAutoDelete.h"


void ShowMessage(const QString& msg)
{
	QWidget* firstTop = QApplication::topLevelWidgets()[0];
	auto topWin = qobject_cast<QTimerAutoDelete*>(firstTop);

	if (topWin)
		topWin->showMessage(msg);
}

static void doDeleteLater(TextCommand *obj)
{
	if (obj->_timer.isActive())
	{
		ShowMessage("deleteLater() will be used!");
	}
	else
	{
		ShowMessage("Usual operator delete() is called!");
	
		QApplication::processEvents();
		QThread::msleep(500);	// to feel the difference ONLY
		delete obj;
	}
}

QTimerAutoDelete::QTimerAutoDelete(QWidget *parent)
	: QMainWindow(parent)
{
	ui.setupUi(this);
}

void QTimerAutoDelete::on_pushButton_clicked()
{
	auto cmd = QSharedPointer<NewTextCommand>();

	cmd.reset(new NewTextCommand, doDeleteLater);

	cmd->execute(ui.checkBox->isChecked());

}

void NewTextCommand::execute(bool bMode)
{
	if (bMode)
	{
		connect(&_timer, &QTimer::timeout, this, &NewTextCommand::onTimer);
		_timer.setSingleShot(true);
		_timer.start(3000);
	}
}

void TextCommand::onTimer(void)
{
	_timer.disconnect();

	ShowMessage("Timer works!!!");

 	QApplication::processEvents();
 	QThread::msleep(500);	// to feel the difference ONLY
	deleteLater();
}
