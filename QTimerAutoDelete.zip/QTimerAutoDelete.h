#pragma once

#include <QtWidgets/QMainWindow>
#include <QTimer>
#include <QMessageBox>

#include "ui_QTimerAutoDelete.h"



class QTimerAutoDelete : public QMainWindow
{
	Q_OBJECT

public:
	QTimerAutoDelete(QWidget *parent = Q_NULLPTR);

	void showMessage(const QString& msg) { ui.label->setText(msg); }

public slots:
	void on_pushButton_clicked();

private:
	Ui::QTimerAutoDeleteClass ui;
};



class TextCommand : public QObject
{
	Q_OBJECT

public:
	TextCommand() {}
	virtual ~TextCommand() { QMessageBox::information(nullptr, "Debug!", "~TextCommand()"); }

	virtual void execute(bool bMode = false) {}

public slots:
	void onTimer(void);

protected:
	QTimer	_timer;

	friend void doDeleteLater(TextCommand *obj);
};



class NewTextCommand : public TextCommand
{
	Q_OBJECT

public:
	NewTextCommand() {}

	virtual void execute(bool bMode = false) override;
};
